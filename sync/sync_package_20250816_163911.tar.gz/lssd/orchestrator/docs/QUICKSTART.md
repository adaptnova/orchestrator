# Quick Start Guide

## Prerequisites

1. **GCP Project Setup**
   - Active GCP project with billing enabled
   - `gcloud` CLI authenticated
   - Required APIs will be enabled by bootstrap script

2. **Local Development**
   - Python 3.10+
   - pip/pipx for package management

## Installation Steps

### 1. Clone and Setup Environment

```bash
# Clone the repository (when GitHub is connected)
git clone https://github.com/adaptnova/agents-gcp.git
cd agents-gcp

# Copy environment template
cp .env.example .claude/projects/agents-gcp/.env
# Edit .env with your project details
```

### 2. Install Dependencies

```bash
# Install in development mode
pip install -e ".[dev]"

# Or just core dependencies
pip install -e .
```

### 3. Bootstrap GCP Infrastructure

```bash
# Make bootstrap script executable
chmod +x scripts/setup/bootstrap.sh

# Run bootstrap (provisions all GCP resources)
./scripts/setup/bootstrap.sh

# Or use Make
make bootstrap
```

### 4. Test Connectivity

```bash
# Test infrastructure connections
python -m src.orchestrator.main test

# Or use Make
make test
```

### 5. Run Orchestrator Locally

```bash
# Execute a task
python -m src.orchestrator.main run "process ETL pipeline"

# Dry run (show plan without executing)
python -m src.orchestrator.main run "train model" --dry-run

# Verbose output
python -m src.orchestrator.main run "deploy agent" --verbose
```

## Common Commands

```bash
# Development
make dev          # Install dev dependencies
make test         # Run all tests
make lint         # Run linting
make format       # Format code

# Operations
make bootstrap    # Provision GCP infrastructure
make run-local    # Run orchestrator locally
make logs         # View Cloud Logging output

# Deployment
make deploy-dev   # Deploy to development
make deploy-staging # Deploy to staging
make deploy-prod  # Deploy to production
```

## Project Structure

```
agents-gcp/
├── src/orchestrator/       # Core orchestrator code
│   ├── main.py            # CLI entry point
│   ├── orchestrator.py    # Planning and execution
│   └── tools.py           # Tool implementations
├── scripts/setup/          # Setup and bootstrap scripts
├── config/                 # Environment configurations
└── docs/                   # Documentation
```

## Next Steps

1. **Customize Tools**: Add your own tools in `src/orchestrator/tools.py`
2. **Enhance Planning**: Improve the planner in `orchestrator.py`
3. **Add Voice**: Integrate Gemini Live API for voice control
4. **Deploy to Vertex AI**: Package and deploy as an agent

## Troubleshooting

### Database Connection Issues
```bash
# Use Cloud SQL Proxy for local development
cloud_sql_proxy -instances=PROJECT:REGION:INSTANCE=tcp:5432

# Test connection
psql -h localhost -U orch_admin -d orch_runs
```

### Storage Access Issues
```bash
# Verify bucket exists
gsutil ls gs://orchestrator-PROJECT-REGION/

# Test write access
echo "test" | gsutil cp - gs://orchestrator-PROJECT-REGION/test.txt
```

### Authentication Issues
```bash
# Re-authenticate
gcloud auth login
gcloud auth application-default login

# Verify project
gcloud config get-value project
```

## Support

For issues or questions:
- Check the [troubleshooting guide](operations/troubleshooting.md)
- Review [operations history](.claude/projects/agents-gcp/operations_history.md)
- See [challenges & solutions](.claude/projects/agents-gcp/challenges_solutions.md)