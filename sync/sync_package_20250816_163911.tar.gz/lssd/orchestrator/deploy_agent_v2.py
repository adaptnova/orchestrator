#!/usr/bin/env python3
"""Deploy Nova Orchestrator to Agent Engine - Working Version"""

import os
import sys
import json
from vertexai.preview import reasoning_engines
from google.cloud import aiplatform

PROJECT = "echovaeris"
LOCATION = "us-central1"
STAGING_BUCKET = "gs://orch-artifacts"

# Set up auth
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

def main():
    print("=" * 60)
    print("NOVA ORCHESTRATOR - AGENT ENGINE DEPLOYMENT V2")
    print("=" * 60)
    
    # Initialize with staging bucket
    aiplatform.init(
        project=PROJECT, 
        location=LOCATION,
        staging_bucket=STAGING_BUCKET
    )
    
    print(f"\n📍 Project: {PROJECT}")
    print(f"📍 Location: {LOCATION}")
    print(f"📍 Staging: {STAGING_BUCKET}")
    
    # Import the reasoning engine class
    sys.path.insert(0, '/agents')
    from nova_reasoning import NovaReasoning
    
    # Create an instance
    print("\n📦 Creating reasoning engine instance...")
    nova = NovaReasoning()
    
    # Test it locally first
    print("\n🧪 Testing locally...")
    local_result = nova.query("Local test before deployment")
    print(f"✅ Local test result: {json.dumps(local_result, indent=2)}")
    
    print("\n🚀 Deploying to Agent Engine...")
    
    try:
        # Deploy the reasoning engine
        remote_agent = reasoning_engines.ReasoningEngine.create(
            nova,  # Pass the actual instance
            requirements=[
                "psycopg2-binary>=2.9.9",
                "google-cloud-storage>=2.16.0"
            ],
            display_name="orchestrator-nova-deployed",
            description="Nova Orchestrator with SQL/GCS receipts - Production",
            sys_version="3.11",  # Specify Python 3.11
            extra_packages=[
                "/agents/nova_reasoning.py",  # Include our module
                "/agents/agent_env.json"       # Include config
            ]
        )
        
        print("\n✅ DEPLOYMENT SUCCESSFUL!")
        print(f"🎯 Agent Resource: {remote_agent.resource_name}")
        
        # Extract the ID
        agent_id = remote_agent.resource_name.split('/')[-1]
        print(f"🆔 Agent ID: {agent_id}")
        
        # Test the deployed agent
        print("\n🧪 Testing deployed agent...")
        deployed_result = remote_agent.query(
            query="Production test from deployed Agent Engine"
        )
        print(f"📊 Deployed test result: {json.dumps(deployed_result, indent=2)}")
        
        print("\n📝 Commands to interact with your agent:")
        print(f"\n# List all reasoning engines:")
        print(f"gcloud ai models list --region={LOCATION}")
        
        print(f"\n# Query your agent (if gcloud supports it):")
        print(f"gcloud ai models query {agent_id} \\")
        print(f"  --region={LOCATION} \\")
        print(f"  --prompt='Generate a production receipt'")
        
        print(f"\n# Check SQL receipts:")
        print(f"# Connect to Cloud SQL and run:")
        print(f"# SELECT * FROM run_events WHERE details->>'source' = 'AGENT_ENGINE_DEPLOYED' ORDER BY id DESC LIMIT 5;")
        
        print(f"\n# Check GCS receipts:")
        print(f"gsutil ls -l gs://orch-artifacts/agent_engine_deployed/")
        
        return remote_agent
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        print(f"\n💡 Error details: {str(e)}")
        
        if "staging_bucket" in str(e):
            print("\n🔧 Fix: Staging bucket issue")
            print("Run: gcloud config set storage/staging_bucket gs://orch-artifacts")
        
        return None

if __name__ == "__main__":
    result = main()
    
    if result:
        print("\n" + "=" * 60)
        print("🎉 AGENT ENGINE DEPLOYMENT COMPLETE!")
        print("=" * 60)
        print("\n🚀 Nova Orchestrator is now running on Agent Engine!")
        print("📊 Receipts are being written to:")
        print("   - Cloud SQL: orch-pg (with 'AGENT_ENGINE_DEPLOYED' tag)")
        print("   - GCS: gs://orch-artifacts/agent_engine_deployed/")
        print("\n✨ No more VM management needed - fully managed by Google!")
    else:
        print("\n⚠️ Deployment failed - check errors above")