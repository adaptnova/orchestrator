#!/bin/bash
set -e

echo "=========================================="
echo "NOVA ORCHESTRATOR - CLOUD RUN DEPLOYMENT"
echo "=========================================="

PROJECT_ID="echovaeris"
REGION="us-central1"
SERVICE_NAME="nova-orchestrator-complete"
SA="orchestrator-nova-sa@${PROJECT_ID}.iam.gserviceaccount.com"

cd /lssd/orchestrator

# Create requirements.txt for Cloud Run
cat > requirements.txt <<EOF
fastapi>=0.116.0
uvicorn>=0.35.0
psycopg2-binary>=2.9.9
redis>=5.0.0
google-cloud-storage>=2.16.0
pydantic>=2.10.0
EOF

# Create Dockerfile
cat > Dockerfile <<EOF
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY nova_complete_cloudrun.py .

# Set environment
ENV PORT=8080
ENV PROJECT_ID=${PROJECT_ID}
ENV REGION=${REGION}
ENV SQL_INSTANCE_ID=orch-pg
ENV SQL_DB_NAME=orch_runs
ENV SQL_USER=orch_admin
ENV SQL_PASS=@@ALALzmzm102938!!
ENV GCS_BUCKET=orch-artifacts
ENV REDIS_HOST=127.0.0.1
ENV REDIS_PORT=6379

# Run the application
CMD ["python", "nova_complete_cloudrun.py"]
EOF

echo "📦 Building and deploying to Cloud Run..."

# Deploy to Cloud Run
gcloud run deploy ${SERVICE_NAME} \
  --region ${REGION} \
  --source . \
  --service-account ${SA} \
  --add-cloudsql-instances ${PROJECT_ID}:${REGION}:orch-pg \
  --set-env-vars "PROJECT_ID=${PROJECT_ID},REGION=${REGION},SQL_INSTANCE_ID=orch-pg,SQL_DB_NAME=orch_runs,SQL_USER=orch_admin,SQL_PASS=@@ALALzmzm102938!!,GCS_BUCKET=orch-artifacts" \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --max-instances 10 \
  --project ${PROJECT_ID}

echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo ""
echo "Service URL will be displayed above"
echo ""
echo "Test endpoints:"
echo "  - / - Service info"
echo "  - /health - Health check"
echo "  - /execute - Execute task (POST)"
echo "  - /proof - Generate proof (GET)"
echo ""
echo "Verify receipts:"
echo "  - Cloud SQL: SELECT * FROM run_events ORDER BY id DESC LIMIT 5;"
echo "  - GCS: gsutil ls gs://orch-artifacts/receipts/cloud_run/"