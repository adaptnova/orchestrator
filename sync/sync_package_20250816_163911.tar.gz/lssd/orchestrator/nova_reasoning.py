#!/usr/bin/env python3
"""Nova Reasoning Engine implementation"""

import os
import json
import psycopg2
from datetime import datetime
from typing import Dict, Any
from google.cloud import storage

class NovaReasoning:
    """Nova Orchestrator Reasoning Engine"""
    
    def __init__(self):
        # Load config from environment or defaults
        self.project_id = os.environ.get("PROJECT_ID", "echovaeris")
        self.region = os.environ.get("REGION", "us-central1")
        self.sql_instance = os.environ.get("SQL_INSTANCE_ID", "orch-pg")
        self.sql_db = os.environ.get("SQL_DB_NAME", "orch_runs")
        self.sql_user = os.environ.get("SQL_USER", "orch_admin")
        self.sql_pass = os.environ.get("SQL_PASS", "@@ALALzmzm102938!!")
        self.gcs_bucket = os.environ.get("GCS_BUCKET", "orch-artifacts")
        self.initialized = False
        self._init_db()
    
    def _init_db(self):
        """Initialize database if needed"""
        try:
            conn = self._get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS run_events (
                    id BIGSERIAL PRIMARY KEY,
                    ts TIMESTAMP NOT NULL DEFAULT NOW(),
                    event_type TEXT NOT NULL,
                    details JSONB NOT NULL
                );
            """)
            conn.commit()
            cur.close()
            conn.close()
            self.initialized = True
        except:
            pass  # DB might already exist
    
    def _get_db_connection(self):
        """Get database connection"""
        socket_path = f"/cloudsql/{self.project_id}:{self.region}:{self.sql_instance}"
        try:
            # Try Unix socket (Agent Engine)
            return psycopg2.connect(
                host=socket_path,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
        except:
            # Fallback to direct IP
            return psycopg2.connect(
                host="34.31.222.209",
                port=5432,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
    
    def query(self, query: str) -> Dict[str, Any]:
        """Process a query and generate receipts
        
        This is the main entry point for Agent Engine.
        """
        
        timestamp = datetime.now().isoformat()
        receipts = {}
        
        # Generate SQL receipt
        try:
            conn = self._get_db_connection()
            cur = conn.cursor()
            
            cur.execute(
                "INSERT INTO run_events (event_type, details) VALUES (%s, %s) RETURNING id, ts",
                ("AGENT_ENGINE_QUERY", json.dumps({
                    "query": query,
                    "timestamp": timestamp,
                    "source": "AGENT_ENGINE_DEPLOYED"
                }))
            )
            event_id, ts = cur.fetchone()
            
            cur.execute("SELECT COUNT(*) FROM run_events WHERE details->>'source' = 'AGENT_ENGINE_DEPLOYED'")
            agent_count = cur.fetchone()[0]
            
            conn.commit()
            cur.close()
            conn.close()
            
            receipts["sql"] = {
                "status": "SUCCESS",
                "event_id": event_id,
                "timestamp": str(ts),
                "agent_engine_events": agent_count
            }
        except Exception as e:
            receipts["sql"] = {
                "status": "ERROR",
                "error": str(e)
            }
        
        # Generate GCS receipt
        try:
            client = storage.Client(project=self.project_id)
            bucket = client.bucket(self.gcs_bucket)
            blob_name = f"agent_engine_deployed/{datetime.now().strftime('%Y%m%d_%H%M%S')}_query.json"
            blob = bucket.blob(blob_name)
            
            content = json.dumps({
                "query": query,
                "timestamp": timestamp,
                "source": "AGENT_ENGINE_DEPLOYED",
                "sql_receipt": receipts.get("sql", {})
            }, indent=2)
            
            blob.upload_from_string(content)
            
            receipts["gcs"] = {
                "status": "SUCCESS",
                "path": f"gs://{self.gcs_bucket}/{blob_name}",
                "size_bytes": len(content)
            }
        except Exception as e:
            receipts["gcs"] = {
                "status": "ERROR", 
                "error": str(e)
            }
        
        return {
            "query": query,
            "timestamp": timestamp,
            "receipts": receipts,
            "message": "Nova Orchestrator on Agent Engine - DEPLOYED!",
            "deployment": "AGENT_ENGINE_PRODUCTION"
        }
    
    def __call__(self, query: str) -> Dict[str, Any]:
        """Make the engine callable"""
        return self.query(query)