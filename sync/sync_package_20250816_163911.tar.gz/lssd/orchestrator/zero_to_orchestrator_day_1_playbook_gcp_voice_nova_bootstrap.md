# Zero-to-Orchestrator: Day‑1 Playbook (GCP) — Voice Nova Bootstrap

This is a **hands-on, minimal-to-productive** path to bring up the first Orchestrator Nova with **voice (Gemini Live API)** and a **task-running brain (ADK on Agent Engine)**. It favors **managed GCP** for speed: Cloud SQL (Postgres), Memorystore (Redis), and Cloud Storage. No containers or k8s required.

---

## 0) Prereqs you must have ready

- A GCP project with billing enabled.
- `gcloud` CLI authenticated to the target project.
- A domain or email for service account notifications.
- Local machine with Python 3.10+ and `pipx` or `uv` (optional but recommended).

> Replace the values in the **env block** once and the scripts will use them. These are not placeholders inside the scripts; they are explicit configuration.

```bash
# === Edit these to your real values ===
export PROJECT_ID="echovaeris"
export REGION="us-central1"
export LOCATION="us-central1"
export ORG_NAME="agents-gcp"
export ORCH_SA_ID="orchestrator-nova-sa"
export ORCH_SA_EMAIL="${ORCH_SA_ID}@${PROJECT_ID}.iam.gserviceaccount.com"
export GCS_BUCKET="orchestrator-${PROJECT_ID}-${REGION}"
export SQL_INSTANCE_ID="orch-pg"
export SQL_DB_NAME="orch_runs"
export SQL_USER="orch_admin"
export SQL_PASS="@@ALALzmzm102938!!"
export REDIS_NAME="orch-redis"
```

---

## 1) Bootstrap script — project, IAM, APIs, and core services

Run once. Safe to re-run; uses idempotent checks where possible.

```bash
#!/usr/bin/env bash
set -euo pipefail

# 1) Project context
 gcloud config set project "$PROJECT_ID"
 gcloud config set compute/region "$REGION"
 gcloud config set ai/region "$REGION" || true

# 2) Enable required services
 gcloud services enable \
   aiplatform.googleapis.com \
   generativelanguage.googleapis.com \
   agentengine.googleapis.com \
   storage.googleapis.com \
   iam.googleapis.com \
   cloudresourcemanager.googleapis.com \
   sqladmin.googleapis.com \
   redis.googleapis.com \
   run.googleapis.com \
   cloudbuild.googleapis.com \
   logging.googleapis.com \
   monitoring.googleapis.com

# 3) Service Account for the Orchestrator
 if ! gcloud iam service-accounts list --format=value\(email\) | grep -q "^${ORCH_SA_EMAIL}$"; then
   gcloud iam service-accounts create "$ORCH_SA_ID" \
     --display-name="${ORG_NAME} Orchestrator Nova"
 fi

# 4) Roles (principle of least privilege; start broad, tighten later)
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/aiplatform.admin"
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/storage.admin"
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/cloudsql.client"
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/redis.admin"
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/run.admin"
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/iam.serviceAccountTokenCreator"
 gcloud projects add-iam-policy-binding "$PROJECT_ID" \
   --member="serviceAccount:${ORCH_SA_EMAIL}" \
   --role="roles/logging.admin"

# 5) Storage bucket for artifacts
 if ! gsutil ls -p "$PROJECT_ID" | grep -q "gs://${GCS_BUCKET}/"; then
   gsutil mb -p "$PROJECT_ID" -l "$REGION" "gs://${GCS_BUCKET}"
 fi

# 6) Cloud SQL Postgres (public IP disabled by default)
 if ! gcloud sql instances describe "$SQL_INSTANCE_ID" --format=json >/dev/null 2>&1; then
   gcloud sql instances create "$SQL_INSTANCE_ID" \
     --database-version=POSTGRES_15 \
     --cpu=2 --memory=7680MB \
     --region="$REGION" \
     --no-assign-ip \
     --root-password="$SQL_PASS"
 fi
 if ! gcloud sql users list --instance="$SQL_INSTANCE_ID" --format=value\(name\) | grep -q "^${SQL_USER}$"; then
   gcloud sql users create "$SQL_USER" --instance="$SQL_INSTANCE_ID" --password="$SQL_PASS"
 fi
 if ! gcloud sql databases list --instance="$SQL_INSTANCE_ID" --format=value\(name\) | grep -q "^${SQL_DB_NAME}$"; then
   gcloud sql databases create "$SQL_DB_NAME" --instance="$SQL_INSTANCE_ID"
 fi

# 7) Memorystore Redis (basic tier to start)
 if ! gcloud redis instances describe "$REDIS_NAME" --region="$REGION" >/dev/null 2>&1; then
   gcloud redis instances create "$REDIS_NAME" \
     --size=1 --region="$REGION" --tier=BASIC
 fi

echo "Bootstrap complete. SA=${ORCH_SA_EMAIL} Bucket=gs://${GCS_BUCKET} SQL=${SQL_INSTANCE_ID} Redis=${REDIS_NAME}"
```

> Notes
>
> - The SQL instance is provisioned without public IP. For access, use Cloud SQL Auth Proxy or connect from Cloud Run/Agent Engine within GCP. Tighten roles once the flow is green.

---

## 2) Minimal Orchestrator agent (ADK) with real side-effect tools

This first cut gives you three concrete tools the agent can call:

- `runs.record_event` — writes run metadata to Postgres.
- `artifacts.write_text` — persists an artifact in Cloud Storage.
- `etl.echo_job` — a do-nothing job that proves planning→acting→receipt. Replace later with your ETL runner.

> Directory: `orchestrator/`

``

```toml
[project]
name = "orchestrator-nova"
version = "0.0.1"
requires-python = ">=3.10"
dependencies = [
  "psycopg[binary]~=3.2",
  "google-cloud-storage~=2.16",
  "google-auth~=2.32",
  "requests~=2.32",
  "adk-sdk>=0.1",  # ADK package name may vary; use actual distribution name
]
```

`` (copy to `.env` and fill exact values)

```bash
PROJECT_ID=${PROJECT_ID}
REGION=${REGION}
GCS_BUCKET=${GCS_BUCKET}
SQL_INSTANCE_ID=${SQL_INSTANCE_ID}
SQL_DB_NAME=${SQL_DB_NAME}
SQL_USER=${SQL_USER}
SQL_PASS=${SQL_PASS}
REDIS_HOST= # fill once created; use instance IP or connector name if via Serverless VPC
```

`` — orchestrator with three tools and a simple plan→act→check loop.

```python
import os, time, json, base64
from datetime import datetime
import psycopg
from google.cloud import storage

# Tool: record run event into Postgres
def runs_record_event(event_type: str, details: dict) -> dict:
    conn_str = (
        f"host=/cloudsql/{os.environ['PROJECT_ID']}:{os.environ['REGION']}:{os.environ['SQL_INSTANCE_ID']} "
        f"dbname={os.environ['SQL_DB_NAME']} user={os.environ['SQL_USER']} password={os.environ['SQL_PASS']}"
    )
    with psycopg.connect(conn_str) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS run_events (
                  id BIGSERIAL PRIMARY KEY,
                  ts TIMESTAMP NOT NULL,
                  event_type TEXT NOT NULL,
                  details JSONB NOT NULL
                )
                """
            )
            cur.execute(
                "INSERT INTO run_events (ts, event_type, details) VALUES (%s, %s, %s) RETURNING id",
                (datetime.utcnow(), event_type, json.dumps(details)),
            )
            run_id = cur.fetchone()[0]
            conn.commit()
    return {"status": "ok", "run_event_id": run_id}

# Tool: write an artifact to GCS
def artifacts_write_text(path: str, content: str) -> dict:
    client = storage.Client(project=os.environ["PROJECT_ID"])
    bucket = client.bucket(os.environ["GCS_BUCKET"])
    blob = bucket.blob(path)
    blob.upload_from_string(content.encode("utf-8"))
    return {"status": "ok", "gs_uri": f"gs://{os.environ['GCS_BUCKET']}/{path}"}

# Tool: dummy ETL job to prove flow
def etl_echo_job(payload: dict) -> dict:
    time.sleep(1)
    return {"status": "ok", "echo": payload, "took_ms": 1000}

# Agent: trivial plan->act->check loop
class Orchestrator:
    def plan(self, goal: str) -> dict:
        return {
            "steps": [
                {"tool": "runs_record_event", "args": {"event_type": "PLAN", "details": {"goal": goal}}},
                {"tool": "etl_echo_job", "args": {"payload": {"goal": goal}}},
                {"tool": "artifacts_write_text", "args": {"path": f"runs/{int(time.time())}.txt", "content": f"goal={goal}"}},
                {"tool": "runs_record_event", "args": {"event_type": "DONE", "details": {"goal": goal}}},
            ]
        }

    def act(self, plan: dict) -> list:
        out = []
        for s in plan["steps"]:
            fn = globals()[s["tool"]]
            out.append({"tool": s["tool"], "result": fn(**s["args"])})
        return out

if __name__ == "__main__":
    agent = Orchestrator()
    p = agent.plan("bootstrap-orchestrator")
    r = agent.act(p)
    print(json.dumps({"plan": p, "results": r}, indent=2))
```

> This is deliberately minimal and **side-effect real**: it writes to Postgres, writes to GCS, and returns receipts. Swap `etl_echo_job` with a real runner when ready.

---

## 3) Connect to **Gemini Live API** for voice control

Start with a CLI invocation pattern; then you can swap in LiveKit or a thin WebRTC client. The Orchestrator remains a local callable.

`` — outline

- Initialize a Live API session with function calling enabled.
- Map function names to the orchestrator’s Python-callable tools.
- Streaming in: user speech → transcript → model. Streaming out: model speech.
- On function call events, execute `runs_record_event`, `artifacts_write_text`, or your ETL/Train tools, return JSON, continue the voice turn.

> Keep voice separate from the task brain. Voice is just IO; the Orchestrator owns planning.

---

## 4) First deployment to **Vertex AI Agent Engine**

Use the Agent Engine quickstart to wrap `adk_app.py` as an agent. Assign the service account, attach project/region, and deploy to a dedicated Engine. Confirm it can reach Cloud SQL (via connector) and GCS.

Checklist:

- Service account bound to the Agent Engine runtime.
- VPC/connector for Cloud SQL.
- Env vars injected via Agent Engine config.
- Logging to Cloud Logging with `run_id` fields.

---

## 5) Replace the dummy ETL with a real job runner

Introduce a single **idempotent** tool with receipts:

- `etl.run(job_name, run_id, params)`
  - Guarantees
    - Returns `{status, run_id, started_at, logs_uri, artifacts[]}`
    - Is idempotent on `run_id`
    - Writes checkpoints to Postgres
  - Backed by: systemd unit or Cloud Run job invoking your ETL code. Logs stream to Cloud Logging.

Add train/eval similarly, with gates:

- `train.start(exp_id, spec_uri)` → `{status, ckpt_uri, logs_uri}`
- `eval.run(exp_id, evalset_uri, metrics[])` → `{status, scores, report_uri}`
- `registry.register(model_uri, meta)` → `{model_id}`
- `deploy.shadow(model_id, traffic_pct)` → `{status}`

---

## 6) Database choices (fastest path)

- **Use managed** for the POC: **Cloud SQL (Postgres)** for run metadata, **Memorystore (Redis)** for queues/locks, **Cloud Storage** for artifacts. This keeps focus on the agent logic, not ops.
- When you need bespoke performance, you can migrate to your preferred self-managed stack without rewriting tools if you keep the tool contracts stable.

---

## 7) Proving “it actually works”

Run this acceptance path end-to-end before adding ML:

1. Run the bootstrap script. Verify SA, bucket, SQL, Redis exist.
2. Run `python adk_app.py`. Confirm:
   - A row in `run_events`
   - A text artifact in `gs://…/runs/*.txt`
3. Wrap the agent in Agent Engine, invoke once via API. Confirm the same receipts.
4. Swap `etl_echo_job` for your smallest ETL task. Confirm logs, receipts, and idempotence.

Green on these four, then add training/eval tools and voice.

---

## 8) Hardening next

- **Policies**: time/cost caps per tool; rollbacks on failed eval gates.
- **Observability**: add `trace_id` to every tool return; integrate with Cloud Trace.
- **Auth**: narrow roles once you validate end-to-end.
- **Evals**: scenario packs in Agent Engine to earn autonomy upgrades.

---

## 9) What to swap next when ready

- Replace Cloud SQL with your preferred Postgres or Scylla/JanusGraph combo for richer lineage.
- Replace Memorystore with DragonflyDB if you need multi-threaded speed.
- Add LiveKit for industrial realtime voice once the Orchestrator is stable.

---

### Done-For-You Command Pack

- Run the **bootstrap script** above after setting the env block.
- Create `.env` from `env.example` and fill true values.
- `python adk_app.py` to smoke-test receipts.
- Deploy to Agent Engine and wire the service account.

This gets you a real Orchestrator Nova with voice-ready plumbing, real state writes, real artifacts, and a clean path to slot in ETL/Train/Eval tools with receipts and gates.

