#!/usr/bin/env python3
"""Deploy Orchestrator Nova to Vertex AI Agent Engine"""

import os
import json
import sys
from google.cloud import aiplatform
from google.cloud.aiplatform_v1beta1 import ReasoningEngineServiceClient
from google.cloud.aiplatform_v1beta1.types import ReasoningEngine, ReasoningEngineSpec

# Set up environment
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

# Load config
with open("/agents/agent_env.json", "r") as f:
    config = json.load(f)

PROJECT_ID = config["PROJECT_ID"]
REGION = config["REGION"]

def deploy_agent():
    """Deploy the orchestrator to Agent Engine"""
    
    print("🚀 Deploying Nova Orchestrator to Agent Engine...")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION
    )
    
    print(f"📍 Project: {PROJECT_ID}")
    print(f"📍 Region: {REGION}")
    
    # Create the reasoning engine specification
    spec = ReasoningEngineSpec(
        package_spec=ReasoningEngineSpec.PackageSpec(
            requirements_gcs_uri=None,  # We'll use inline requirements
            python_module="agent_entry",
            handler="create_agent"
        ),
        runtime_config={
            "PROJECT_ID": PROJECT_ID,
            "REGION": REGION,
            "SQL_INSTANCE_ID": config["SQL_INSTANCE_ID"],
            "SQL_DB_NAME": config["SQL_DB_NAME"],
            "SQL_USER": config["SQL_USER"],
            "SQL_PASS": config["SQL_PASS"],
            "GCS_BUCKET": config["GCS_BUCKET"]
        }
    )
    
    # Create the reasoning engine
    engine = ReasoningEngine(
        display_name="orchestrator-nova-agent",
        description="Nova Orchestrator with SQL and GCS receipts",
        spec=spec
    )
    
    # Deploy using the service client
    client = ReasoningEngineServiceClient(
        client_options={"api_endpoint": f"{REGION}-aiplatform.googleapis.com"}
    )
    
    parent = f"projects/{PROJECT_ID}/locations/{REGION}"
    
    print("📦 Creating reasoning engine...")
    
    try:
        # Create the engine
        operation = client.create_reasoning_engine(
            parent=parent,
            reasoning_engine=engine
        )
        
        print("⏳ Waiting for deployment...")
        result = operation.result(timeout=300)  # 5 minute timeout
        
        print("✅ Deployment successful!")
        print(f"🎯 Engine ID: {result.name}")
        print(f"🔗 Resource: {result}")
        
        # Generate test commands
        engine_id = result.name.split("/")[-1]
        print("\n📝 Test your agent with:")
        print(f"gcloud ai reasoning-engines query {engine_id} \\")
        print(f'  --region={REGION} \\')
        print(f'  --query="Generate a receipt for testing"')
        
        return result
        
    except Exception as e:
        print(f"❌ Deployment failed: {e}")
        return None

def deploy_with_sdk():
    """Alternative deployment using SDK directly"""
    
    print("\n🔧 Alternative: Deploying with SDK...")
    
    # Initialize
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION
    )
    
    # Create reasoning engine using SDK
    from vertexai.preview import reasoning_engines
    
    # Define the agent class inline
    agent_code = '''
import os
import json
import psycopg2
from datetime import datetime
from typing import Dict, Any
from google.cloud import storage

class NovaAgent:
    def __init__(self):
        self.project_id = os.environ.get("PROJECT_ID", "echovaeris")
        self.bucket = os.environ.get("GCS_BUCKET", "orch-artifacts")
        
    def query(self, task: str) -> Dict[str, Any]:
        """Process a task and generate receipts"""
        
        # Generate receipts
        timestamp = datetime.now().isoformat()
        
        receipt = {
            "task": task,
            "timestamp": timestamp,
            "source": "AGENT_ENGINE",
            "project": self.project_id,
            "bucket": self.bucket,
            "message": "Nova Agent Engine is operational!"
        }
        
        return receipt
'''
    
    try:
        # Create temporary module
        with open("/tmp/nova_agent.py", "w") as f:
            f.write(agent_code)
        
        # Deploy
        print("📤 Uploading agent code...")
        
        agent = reasoning_engines.ReasoningEngine.create(
            display_name="nova-orchestrator-sdk",
            description="Nova Orchestrator deployed via SDK",
            requirements=["psycopg2-binary", "google-cloud-storage"],
            handler="NovaAgent",
            extra_files=["/tmp/nova_agent.py"],
            runtime_config=config
        )
        
        print(f"✅ SDK deployment successful!")
        print(f"🎯 Agent: {agent}")
        
        # Test the agent
        print("\n🧪 Testing agent...")
        response = agent.query("Generate a test receipt")
        print(f"📊 Response: {json.dumps(response, indent=2)}")
        
        return agent
        
    except Exception as e:
        print(f"❌ SDK deployment failed: {e}")
        print(f"💡 Error details: {str(e)}")
        return None

if __name__ == "__main__":
    print("=" * 60)
    print("NOVA ORCHESTRATOR - AGENT ENGINE DEPLOYMENT")
    print("=" * 60)
    
    # Try primary deployment method
    result = deploy_agent()
    
    if not result:
        print("\n🔄 Trying alternative SDK deployment...")
        result = deploy_with_sdk()
    
    if result:
        print("\n🎉 DEPLOYMENT COMPLETE!")
        print("📊 Your orchestrator is now running in Agent Engine")
        print("🔍 Check the GCP Console > Vertex AI > Agent Builder")
        print("💾 Receipts will be written to:")
        print(f"   - Cloud SQL: {config['SQL_INSTANCE_ID']}")
        print(f"   - GCS: gs://{config['GCS_BUCKET']}/")
    else:
        print("\n⚠️ Deployment needs manual intervention")
        print("📚 Check: https://cloud.google.com/vertex-ai/docs/reasoning-engine")