#!/usr/bin/env python3
"""Query the deployed Nova Agent Engine"""

import os
import json
from vertexai.preview import reasoning_engines
from google.cloud import aiplatform

PROJECT = "echovaeris"
LOCATION = "us-central1"

# Set up auth
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

def main():
    print("=" * 60)
    print("NOVA AGENT ENGINE - QUERY TEST")
    print("=" * 60)
    
    # Initialize
    aiplatform.init(project=PROJECT, location=LOCATION)
    
    print(f"\n📍 Project: {PROJECT}")
    print(f"📍 Location: {LOCATION}")
    
    print("\n🔍 Finding deployed agents...")
    
    try:
        # List all reasoning engines
        engines = reasoning_engines.ReasoningEngine.list()
        
        if not engines:
            print("❌ No agents found")
            return None
        
        print(f"✅ Found {len(engines)} agent(s):")
        
        # Find our Nova agent
        nova_agent = None
        for engine in engines:
            print(f"  - {engine.display_name}: {engine.resource_name}")
            if "nova" in engine.display_name.lower():
                nova_agent = engine
        
        if not nova_agent:
            # Just use the first one
            nova_agent = engines[0]
            print(f"\n⚠️ No 'nova' agent found, using: {nova_agent.display_name}")
        else:
            print(f"\n✅ Using Nova agent: {nova_agent.display_name}")
        
        # Extract the ID
        agent_id = nova_agent.resource_name.split('/')[-1]
        print(f"🆔 Agent ID: {agent_id}")
        
        # Query the agent
        print("\n🚀 Querying deployed agent...")
        
        query = "Generate a production receipt from Agent Engine"
        print(f"📝 Query: {query}")
        
        try:
            # Query using the agent instance
            response = nova_agent.query(query=query)
            
            print("\n✅ QUERY SUCCESSFUL!")
            print("\n📊 Response:")
            
            # Pretty print the response
            if isinstance(response, dict):
                print(json.dumps(response, indent=2))
            else:
                print(response)
            
            # Check if receipts were generated
            if isinstance(response, dict) and "receipts" in response:
                print("\n📋 Receipt Summary:")
                
                if "sql" in response["receipts"]:
                    sql = response["receipts"]["sql"]
                    if sql.get("status") == "SUCCESS":
                        print(f"  ✅ SQL: Event ID {sql.get('event_id')} written")
                        print(f"     Total Agent Engine events: {sql.get('agent_engine_events', 'unknown')}")
                    else:
                        print(f"  ❌ SQL: {sql.get('error', 'Failed')}")
                
                if "gcs" in response["receipts"]:
                    gcs = response["receipts"]["gcs"]
                    if gcs.get("status") == "SUCCESS":
                        print(f"  ✅ GCS: {gcs.get('path')}")
                    else:
                        print(f"  ❌ GCS: {gcs.get('error', 'Failed')}")
            
            return response
            
        except Exception as query_error:
            print(f"\n❌ Query failed: {query_error}")
            
            # Try alternative query method
            print("\n🔄 Trying alternative query method...")
            
            try:
                # Some versions might use different method names
                if hasattr(nova_agent, 'predict'):
                    response = nova_agent.predict(query)
                elif hasattr(nova_agent, 'invoke'):
                    response = nova_agent.invoke(query)
                elif hasattr(nova_agent, '__call__'):
                    response = nova_agent(query)
                else:
                    print("❌ No known query method found")
                    return None
                
                print("✅ Alternative method worked!")
                print(f"📊 Response: {response}")
                return response
                
            except Exception as alt_error:
                print(f"❌ Alternative also failed: {alt_error}")
                return None
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return None

if __name__ == "__main__":
    result = main()
    
    if result:
        print("\n" + "=" * 60)
        print("🎉 AGENT ENGINE QUERY SUCCESSFUL!")
        print("=" * 60)
        print("\n📊 Your Nova Orchestrator is:")
        print("   ✅ Deployed to Agent Engine")
        print("   ✅ Responding to queries")
        print("   ✅ Writing receipts to SQL and GCS")
        print("\n🚀 Production ready!")