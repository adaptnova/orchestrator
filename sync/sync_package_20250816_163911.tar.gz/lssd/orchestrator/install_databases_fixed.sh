#!/bin/bash
set -e

echo "=========================================="
echo "NOVA ORCHESTRATOR - COMPLETE DB SETUP"
echo "=========================================="

# 1. PostgreSQL with pgvector (Ubuntu 24.04 uses PostgreSQL 16)
echo -e "\n[1/4] Installing PostgreSQL with pgvector..."
sudo apt-get update
sudo apt-get install -y postgresql postgresql-client postgresql-contrib

# Install pgvector
sudo apt-get install -y postgresql-16-pgvector || {
    # If package not available, build from source
    sudo apt-get install -y postgresql-server-dev-16 make gcc
    cd /tmp
    git clone https://github.com/pgvector/pgvector.git
    cd pgvector
    make
    sudo make install
    cd /
}

# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create user and database
sudo -u postgres psql -c "CREATE ROLE nova WITH LOGIN PASSWORD 'NovaP@ssw0rd!2025';" || echo "User exists"
sudo -u postgres psql -c "CREATE DATABASE nova_db OWNER nova;" || echo "DB exists"
sudo -u postgres psql -d nova_db -c "CREATE EXTENSION IF NOT EXISTS vector;"

# Test PostgreSQL
PGPASSWORD='NovaP@ssw0rd!2025' psql -h 127.0.0.1 -U nova -d nova_db -c "SELECT version();" && echo "✅ PostgreSQL ready"

# 2. Qdrant Vector DB
echo -e "\n[2/4] Installing Qdrant..."
sudo useradd -r -s /usr/sbin/nologin qdrant || echo "User exists"
sudo mkdir -p /var/lib/qdrant /etc/qdrant

# Download Qdrant binary
if [ ! -f /usr/local/bin/qdrant ]; then
    echo "Downloading Qdrant..."
    wget -q -O /usr/local/bin/qdrant https://github.com/qdrant/qdrant/releases/download/v1.8.3/qdrant-x86_64-unknown-linux-gnu
    sudo chmod +x /usr/local/bin/qdrant
fi

# Create config
sudo tee /etc/qdrant/config.yaml >/dev/null <<'CFG'
storage:
  path: "/var/lib/qdrant"
cluster:
  enabled: false
service:
  http_port: 6333
  grpc_port: 6334
CFG

# Create systemd service
sudo tee /etc/systemd/system/qdrant.service >/dev/null <<'UNIT'
[Unit]
Description=Qdrant Vector DB
After=network.target

[Service]
User=qdrant
Group=qdrant
WorkingDirectory=/var/lib/qdrant
ExecStart=/usr/local/bin/qdrant --storage /var/lib/qdrant --config /etc/qdrant/config.yaml
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
UNIT

# Fix permissions and start
sudo chown -R qdrant:qdrant /var/lib/qdrant || true
sudo systemctl daemon-reload
sudo systemctl enable --now qdrant || echo "Qdrant already running"

# Wait for startup
sleep 5

# Create collection
curl -s -X PUT http://127.0.0.1:6333/collections/nova_mem \
  -H 'Content-Type: application/json' \
  -d '{"vectors":{"size":1536,"distance":"Cosine"}}' && echo "✅ Qdrant ready"

# 3. Install Python dependencies for orchestrator
echo -e "\n[3/4] Installing Python dependencies..."
pip3 install --user psycopg2-binary redis requests cassandra-driver google-cloud-storage

# 4. Check existing services
echo -e "\n[4/4] Checking services..."

# PostgreSQL
sudo -u postgres psql -c "SELECT 1;" > /dev/null 2>&1 && echo "✅ PostgreSQL running" || echo "❌ PostgreSQL not running"

# Qdrant
curl -s http://127.0.0.1:6333/collections > /dev/null 2>&1 && echo "✅ Qdrant running" || echo "❌ Qdrant not running"

# Dragonfly/Redis
redis-cli ping > /dev/null 2>&1 && echo "✅ Dragonfly/Redis running" || echo "❌ Dragonfly/Redis not running"

echo -e "\n=========================================="
echo "DATABASE SETUP STATUS"
echo "=========================================="
echo "Services:"
echo "  - PostgreSQL: 5432"
echo "  - Qdrant: 6333"
echo "  - Dragonfly/Redis: 6379"
echo ""
echo "Next: Run the complete orchestrator test"
echo "python3 /lssd/orchestrator/nova_orchestrator_complete.py"