# Dialogflow CX Reference Guide

## Overview
Dialogflow CX is Google's enterprise conversational AI platform for building sophisticated virtual agents with advanced NLU capabilities.

## Key Concepts

### 1. Agents
- Conversational interfaces that handle user interactions
- Support for multi-language and multi-channel deployment
- Integration with telephony, chat, and voice assistants

### 2. Flows & Pages
- **Flows**: Conversation topics organized as state machines
- **Pages**: States within flows that collect information
- **State Handlers**: Define conversational turns within pages

### 3. Intents & Entities
- **Intents**: Categories of user intentions
- **Training Phrases**: Examples to train intent matching
- **Entities**: Extract structured data from user input
- **System Entities**: Pre-built entities (dates, numbers, etc.)

### 4. Fulfillment & Webhooks
- Backend integration for dynamic responses
- Webhook calls for business logic execution
- Integration with Cloud Functions and Cloud Run

### 5. Test & Version Management
- Test cases for automated testing
- Version control for agent configurations
- Environments for staging and production

## Essential gcloud Commands

### Authentication & Setup
```bash
# Set project and region
gcloud config set project echovaeris
gcloud config set dialogflow/location us-central1

# Enable Dialogflow API
gcloud services enable dialogflow.googleapis.com
```

### Agent Management (Using REST API via gcloud)
```bash
# List agents (via API)
curl -X GET \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents"

# Create agent via API
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "displayName": "orchestrator-agent",
    "defaultLanguageCode": "en",
    "timeZone": "America/Chicago",
    "description": "Orchestrator Nova Voice Agent"
  }' \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents"
```

### Using gcloud alpha commands (when available)
```bash
# Export agent
gcloud alpha dialogflow agent export \
  --project=echovaeris \
  --destination=gs://echovaeris-dialogflow-backups/agent-backup.zip

# Import agent
gcloud alpha dialogflow agent import \
  --project=echovaeris \
  --source=gs://echovaeris-dialogflow-backups/agent-backup.zip

# Train agent
gcloud alpha dialogflow agent train --project=echovaeris
```

### Intent Management
```bash
# List intents
gcloud alpha dialogflow intents list --project=echovaeris

# Create intent
gcloud alpha dialogflow intents create \
  --project=echovaeris \
  --display-name="orchestrator.run_task" \
  --training-phrases="run the task,execute task,start task" \
  --message-texts="Starting task execution..."
```

### Entity Management
```bash
# List entity types
gcloud alpha dialogflow entity-types list --project=echovaeris

# Create entity type
gcloud alpha dialogflow entity-types create \
  --project=echovaeris \
  --display-name="task_type" \
  --kind=KIND_MAP \
  --entities="etl:etl,extract transform load|training:train,model training|evaluation:eval,evaluate"
```

### Webhook Configuration
```bash
# Deploy webhook to Cloud Functions
gcloud functions deploy dialogflow-webhook \
  --runtime=python39 \
  --trigger-http \
  --allow-unauthenticated \
  --entry-point=webhook \
  --region=us-central1 \
  --set-env-vars="PROJECT_ID=echovaeris"

# Get webhook URL
gcloud functions describe dialogflow-webhook \
  --region=us-central1 \
  --format="value(httpsTrigger.url)"
```

### Testing & Validation
```bash
# Detect intent (test query)
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "queryInput": {
      "text": {
        "text": "run ETL pipeline",
        "languageCode": "en"
      }
    }
  }' \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID/sessions/test-session:detectIntent"
```

### Environment Management
```bash
# List environments
curl -X GET \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID/environments"

# Create environment
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "displayName": "production",
    "description": "Production environment"
  }' \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID/environments"
```

## Integration with Vertex AI

### Connect Dialogflow to Vertex AI Agent
```bash
# Create integration configuration
cat > dialogflow-vertex-config.json << EOF
{
  "vertexAiSettings": {
    "project": "echovaeris",
    "location": "us-central1",
    "model": "gemini-1.5-pro",
    "enableGrounding": true,
    "enableFunctionCalling": true
  }
}
EOF

# Apply configuration
curl -X PATCH \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d @dialogflow-vertex-config.json \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID"
```

### Enable Voice Features
```bash
# Configure speech settings
cat > speech-config.json << EOF
{
  "speechToTextSettings": {
    "enableSpeechAdaptation": true,
    "model": "latest_long",
    "audioEncoding": "AUDIO_ENCODING_LINEAR_16",
    "sampleRateHertz": 16000,
    "languageCode": "en-US"
  },
  "textToSpeechSettings": {
    "synthesizeSpeechConfigs": {
      "en": {
        "voice": {
          "name": "en-US-Neural2-F",
          "ssmlGender": "FEMALE"
        }
      }
    }
  }
}
EOF

# Apply speech configuration
curl -X PATCH \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d @speech-config.json \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID"
```

## Function Calling Integration

### Define Functions for Orchestrator
```json
{
  "functions": [
    {
      "name": "runs_record_event",
      "description": "Record an event in the orchestrator run log",
      "parameters": {
        "type": "object",
        "properties": {
          "event_type": {
            "type": "string",
            "description": "Type of event (PLAN, EXECUTE, DONE, ERROR)"
          },
          "details": {
            "type": "object",
            "description": "Event details"
          }
        },
        "required": ["event_type", "details"]
      }
    },
    {
      "name": "artifacts_write_text",
      "description": "Write text artifact to storage",
      "parameters": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "description": "Storage path for artifact"
          },
          "content": {
            "type": "string",
            "description": "Content to write"
          }
        },
        "required": ["path", "content"]
      }
    },
    {
      "name": "etl_run_job",
      "description": "Execute an ETL job",
      "parameters": {
        "type": "object",
        "properties": {
          "job_name": {
            "type": "string",
            "description": "Name of the ETL job"
          },
          "parameters": {
            "type": "object",
            "description": "Job parameters"
          }
        },
        "required": ["job_name"]
      }
    }
  ]
}
```

## Best Practices

1. **Use Flows for Complex Conversations**: Organize related intents into flows
2. **Implement Proper Error Handling**: Use system events for no-match and no-input
3. **Version Control**: Tag stable versions before major changes
4. **Test Coverage**: Create comprehensive test suites for all flows
5. **Webhook Security**: Use authentication and validate requests
6. **Monitor Performance**: Track fulfillment latency and success rates
7. **Multi-language Support**: Design with internationalization in mind

## Troubleshooting Commands

```bash
# Check agent status
curl -X GET \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID"

# View agent logs
gcloud logging read "resource.type=dialogflow_agent" \
  --project=echovaeris \
  --limit=50 \
  --format=json

# Test webhook connectivity
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"test": true}' \
  $(gcloud functions describe dialogflow-webhook --region=us-central1 --format="value(httpsTrigger.url)")

# Export agent for backup
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -d '{"agentUri": "gs://echovaeris-dialogflow-backups/agent-$(date +%Y%m%d).zip"}' \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/AGENT_ID:export"
```

## Quick Start for Orchestrator Nova

```bash
# 1. Create the agent
AGENT_RESPONSE=$(curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "displayName": "Orchestrator Nova",
    "defaultLanguageCode": "en",
    "timeZone": "America/Chicago",
    "description": "Voice-enabled orchestrator with Gemini Live integration"
  }' \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents")

# 2. Extract agent ID
AGENT_ID=$(echo $AGENT_RESPONSE | jq -r '.name' | rev | cut -d'/' -f1 | rev)

# 3. Configure Vertex AI integration
curl -X PATCH \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "advancedSettings": {
      "loggingSettings": {
        "enableStackdriverLogging": true,
        "enableInteractionLogging": true
      }
    }
  }' \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents/$AGENT_ID"

echo "Agent created with ID: $AGENT_ID"
```