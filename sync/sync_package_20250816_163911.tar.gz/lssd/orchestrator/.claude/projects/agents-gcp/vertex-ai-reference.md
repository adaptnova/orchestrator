# Vertex AI Reference Guide

## Overview
Vertex AI is Google Cloud's unified ML platform that brings together data engineering, data science, and ML engineering workflows.

## Key Components

### 1. Vertex AI Agent Builder
- Build conversational AI agents with grounding in enterprise data
- Integration with Gemini models for advanced reasoning
- Support for tool calling and function execution

### 2. Model Garden
- Access to 100+ foundation models including Gemini, PaLM, Claude, Llama
- Fine-tuning capabilities for custom models
- Model evaluation and comparison tools

### 3. Vertex AI Studio
- Interactive environment for prompt engineering
- Multi-modal capabilities (text, image, video, audio)
- Batch prediction and online serving

### 4. Vector Search (Matching Engine)
- High-performance similarity matching
- Sub-millisecond latency at billion-scale
- Integration with embedding models

## Essential gcloud Commands

### Project Setup
```bash
# Set project context
gcloud config set project echovaeris
gcloud config set ai/region us-central1

# Enable required APIs
gcloud services enable aiplatform.googleapis.com
gcloud services enable notebooks.googleapis.com
gcloud services enable ml.googleapis.com
```

### Agent Builder Commands
```bash
# List available agents
gcloud ai agents list --location=us-central1

# Create a new agent
gcloud ai agents create \
  --display-name="orchestrator-nova" \
  --location=us-central1 \
  --agent-type=conversational

# Deploy an agent
gcloud ai agents deploy AGENT_ID \
  --location=us-central1 \
  --environment=production

# Test an agent
gcloud ai agents test AGENT_ID \
  --location=us-central1 \
  --query="Hello, how can you help?"
```

### Model Management
```bash
# List available models
gcloud ai models list --region=us-central1

# Upload a model
gcloud ai models upload \
  --region=us-central1 \
  --display-name="custom-orchestrator-model" \
  --artifact-uri=gs://echovaeris-models/orchestrator/

# Create an endpoint
gcloud ai endpoints create \
  --region=us-central1 \
  --display-name="orchestrator-endpoint"

# Deploy model to endpoint
gcloud ai endpoints deploy-model ENDPOINT_ID \
  --region=us-central1 \
  --model=MODEL_ID \
  --display-name="orchestrator-v1" \
  --machine-type=n1-standard-4 \
  --min-replica-count=1 \
  --max-replica-count=3 \
  --traffic-split=0=100
```

### Training Jobs
```bash
# Submit a training job
gcloud ai custom-jobs create \
  --region=us-central1 \
  --display-name="agent-training-job" \
  --worker-pool-spec=machine-type=n1-standard-8,replica-count=1,accelerator-type=NVIDIA_TESLA_T4,accelerator-count=1 \
  --python-package-uris=gs://echovaeris-training/packages/trainer-0.1.tar.gz \
  --module-name=trainer.task \
  --args="--epochs=10,--batch_size=32"

# Monitor training job
gcloud ai custom-jobs describe JOB_ID --region=us-central1

# Stream logs
gcloud ai custom-jobs stream-logs JOB_ID --region=us-central1
```

### Batch Predictions
```bash
# Create batch prediction job
gcloud ai batch-prediction-jobs create \
  --region=us-central1 \
  --model=MODEL_ID \
  --input-format=jsonl \
  --gcs-source=gs://echovaeris-data/input.jsonl \
  --gcs-destination=gs://echovaeris-predictions/ \
  --machine-type=n1-standard-4
```

### Pipeline Management
```bash
# Create a pipeline
gcloud ai pipelines create \
  --region=us-central1 \
  --display-name="agent-training-pipeline" \
  --pipeline-spec=pipeline_spec.yaml

# Run a pipeline
gcloud ai pipeline-jobs create \
  --region=us-central1 \
  --display-name="training-run-001" \
  --pipeline=PIPELINE_ID \
  --parameter-values=epochs=10,learning_rate=0.001
```

### Dataset Management
```bash
# Create dataset
gcloud ai datasets create \
  --region=us-central1 \
  --display-name="agent-training-data" \
  --metadata-schema-uri=gs://google-cloud-aiplatform/schema/dataset/metadata/text_1.0.0.yaml

# Import data
gcloud ai datasets import \
  --region=us-central1 \
  --dataset=DATASET_ID \
  --gcs-source=gs://echovaeris-data/training_data.jsonl \
  --import-schema-uri=gs://google-cloud-aiplatform/schema/dataset/ioformat/text_single_label_classification_io_format_1.0.0.yaml
```

### Feature Store
```bash
# Create feature store
gcloud ai feature-stores create agent-features \
  --region=us-central1 \
  --online-store-fixed-node-count=1

# Create entity type
gcloud ai feature-stores entity-types create user \
  --feature-store=agent-features \
  --region=us-central1 \
  --description="User entity for agent personalization"

# Create features
gcloud ai feature-stores features create interaction_count \
  --entity-type=user \
  --feature-store=agent-features \
  --region=us-central1 \
  --value-type=INT64 \
  --description="Number of user interactions"
```

### Metadata Management
```bash
# Create metadata store
gcloud ai metadata-stores create \
  --region=us-central1 \
  --metadata-store=agent-metadata

# Create execution
gcloud ai metadata-stores executions create \
  --region=us-central1 \
  --metadata-store=agent-metadata \
  --execution=training-run-001 \
  --display-name="Training Run 001" \
  --metadata='{"parameters": {"epochs": 10, "batch_size": 32}}'
```

### Tensorboard Integration
```bash
# Create Tensorboard instance
gcloud ai tensorboards create \
  --display-name="agent-training-metrics" \
  --region=us-central1

# Create experiment
gcloud ai tensorboards experiments create \
  --tensorboard=TENSORBOARD_ID \
  --tensorboard-experiment-id=exp-001 \
  --display-name="Orchestrator Training Experiment" \
  --region=us-central1
```

### Index Management (Vector Search)
```bash
# Create index
gcloud ai indexes create \
  --display-name="agent-knowledge-index" \
  --metadata-file=index_metadata.json \
  --region=us-central1

# Deploy index to endpoint
gcloud ai index-endpoints deploy-index INDEX_ENDPOINT_ID \
  --deployed-index-id="deployed-agent-index" \
  --display-name="Agent Knowledge Index" \
  --index=INDEX_ID \
  --region=us-central1
```

## Advanced Flags and Options

### Common Flags
- `--async`: Run command asynchronously
- `--format=json`: Output in JSON format
- `--filter="..."`: Filter results
- `--limit=N`: Limit number of results
- `--sort-by=FIELD`: Sort results
- `--verbosity=debug`: Increase output verbosity
- `--log-http`: Log HTTP requests/responses

### Resource Management Flags
- `--max-replica-count`: Maximum number of replicas
- `--min-replica-count`: Minimum number of replicas
- `--machine-type`: Machine type for compute resources
- `--accelerator-type`: GPU type
- `--accelerator-count`: Number of GPUs

### Security Flags
- `--service-account`: Service account for resource
- `--network`: VPC network
- `--enable-private-ip`: Use private IP only
- `--encryption-key`: Customer-managed encryption key

## Best Practices

1. **Always specify region**: Use `--region=us-central1` consistently
2. **Use labels**: Add labels for resource organization and cost tracking
3. **Enable monitoring**: Use `--enable-logging` and `--enable-monitoring`
4. **Version control**: Tag models and pipelines with versions
5. **Use service accounts**: Implement least-privilege access
6. **Batch operations**: Use batch predictions for cost optimization
7. **Resource cleanup**: Delete unused endpoints and models

## Integration with Agent Development

### For Orchestrator Nova
```bash
# Quick setup for orchestrator agent
gcloud ai agents create \
  --display-name="orchestrator-nova" \
  --location=us-central1 \
  --agent-type=conversational \
  --grounding-config='{
    "sources": [{
      "type": "vertex_ai_search",
      "datastore": "projects/echovaeris/locations/us-central1/datastores/agent-knowledge"
    }]
  }' \
  --tool-config='{
    "function_calling_config": {
      "mode": "ANY",
      "allowed_function_names": ["runs_record_event", "artifacts_write_text", "etl_echo_job"]
    }
  }'
```

### For Voice Integration
```bash
# Enable voice capabilities
gcloud ai agents update AGENT_ID \
  --location=us-central1 \
  --update-voice-config='{
    "voice_model": "gemini-1.5-flash-latest",
    "enable_streaming": true,
    "language_code": "en-US"
  }'
```