# Challenges & Solutions Log

## Project: Agents GCP - Orchestrator Nova
**Lead**: Chase  
**Organization**: AdaptNova

---

### August 15, 2025 2:55 PM MST
**Challenge**: Dialogflow CX gcloud Commands Not Available
**Severity**: Medium
**Status**: Resolved

**Problem**:
- Standard gcloud commands for Dialogflow CX are not available in the CLI
- `gcloud alpha dialogflow cx` commands don't exist in current SDK

**Solution**:
- Use REST API with curl and gcloud auth tokens for Dialogflow operations
- Created comprehensive REST API examples in dialogflow-reference.md
- Alternative: Use Python client libraries for programmatic access

**Implementation**:
```bash
# Use REST API with auth token
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d @agent-config.json \
  "https://us-central1-dialogflow.googleapis.com/v3/projects/echovaeris/locations/us-central1/agents"
```

---

### August 15, 2025 2:50 PM MST
**Challenge**: Redis API Not Enabled
**Severity**: Low
**Status**: Pending

**Problem**:
- Google Cloud Memorystore for Redis API not enabled on project
- Cannot list or create Redis instances without enabling API

**Solution**:
- Will enable during bootstrap phase
- Add to bootstrap script: `gcloud services enable redis.googleapis.com`
- Alternative: Use Cloud Run with in-memory cache for POC

**Next Steps**:
- Enable Redis API in bootstrap script
- Create Redis instance for queue management
- Document connection string in .env

---

### August 15, 2025 2:40 PM MST
**Challenge**: No Existing Cloud SQL Instances
**Severity**: Low
**Status**: Expected

**Problem**:
- No Cloud SQL instances exist in the project
- Need to create PostgreSQL instance for state management

**Solution**:
- This is expected for a new project
- Bootstrap script will create required instances
- Using managed Cloud SQL for simplicity over self-hosted

**Configuration**:
```bash
SQL_INSTANCE_ID="orch-pg"
SQL_DB_NAME="orch_runs"
SQL_USER="orch_admin"
SQL_PASS="@@ALALzmzm102938!!"
```

---

### August 15, 2025 2:35 PM MST
**Challenge**: Service Account Permissions
**Severity**: Medium
**Status**: Planning

**Problem**:
- Need to create orchestrator-nova-sa service account
- Must grant appropriate IAM roles for all services
- Balance between functionality and security

**Solution**:
- Start with broad permissions for POC
- Document required roles in bootstrap script
- Plan to narrow permissions after validation
- Use workload identity for production

**Required Roles**:
- roles/aiplatform.admin
- roles/storage.admin
- roles/cloudsql.client
- roles/redis.admin
- roles/run.admin
- roles/iam.serviceAccountTokenCreator
- roles/logging.admin

---