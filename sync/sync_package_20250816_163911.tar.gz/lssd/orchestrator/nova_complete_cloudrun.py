#!/usr/bin/env python3
"""Nova Orchestrator for Cloud Run with Complete DB Integration"""

import os
import json
import psycopg2
import redis
from datetime import datetime
from typing import Dict, Any
from google.cloud import storage
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uuid
import hashlib

app = FastAPI(
    title="Nova Orchestrator Complete",
    description="Orchestrator with all database integrations",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TaskRequest(BaseModel):
    task: str
    context: Dict[str, Any] = {}

class NovaOrchestrator:
    def __init__(self):
        # GCP Configuration
        self.project_id = os.environ.get("PROJECT_ID", "echovaeris")
        self.region = os.environ.get("REGION", "us-central1")
        self.gcs_bucket = os.environ.get("GCS_BUCKET", "orch-artifacts")
        
        # Cloud SQL
        self.sql_instance = os.environ.get("SQL_INSTANCE_ID", "orch-pg")
        self.sql_db = os.environ.get("SQL_DB_NAME", "orch_runs")
        self.sql_user = os.environ.get("SQL_USER", "orch_admin")
        self.sql_pass = os.environ.get("SQL_PASS", "@@ALALzmzm102938!!")
        
        # Local PostgreSQL (if available)
        self.local_pg_enabled = os.environ.get("LOCAL_PG_ENABLED", "false").lower() == "true"
        
        # Redis/Dragonfly
        self.redis_host = os.environ.get("REDIS_HOST", "127.0.0.1")
        self.redis_port = int(os.environ.get("REDIS_PORT", "6379"))
        
        self.init_databases()
    
    def init_databases(self):
        """Initialize database tables"""
        try:
            conn = self._get_cloud_sql_connection()
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS run_events (
                    id BIGSERIAL PRIMARY KEY,
                    ts TIMESTAMP NOT NULL DEFAULT NOW(),
                    event_type TEXT NOT NULL,
                    details JSONB NOT NULL
                );
                CREATE TABLE IF NOT EXISTS runs (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    created_at TIMESTAMP DEFAULT NOW(),
                    status TEXT DEFAULT 'pending'
                );
                CREATE TABLE IF NOT EXISTS artifacts (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    run_id UUID,
                    path TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT NOW()
                );
            """)
            conn.commit()
            cur.close()
            conn.close()
            print("✅ Database initialized")
        except Exception as e:
            print(f"Database init error: {e}")
    
    def _get_cloud_sql_connection(self):
        """Get Cloud SQL connection - works in Cloud Run"""
        # In Cloud Run, use Unix socket
        if os.environ.get("K_SERVICE"):
            socket_path = f"/cloudsql/{self.project_id}:{self.region}:{self.sql_instance}"
            return psycopg2.connect(
                host=socket_path,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
        else:
            # Local development
            return psycopg2.connect(
                host="34.31.222.209",
                port=5432,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
    
    def execute_complete_run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a complete run touching all databases"""
        
        run_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        receipts = {}
        counters = {}
        
        # 1. Cloud SQL - Primary database
        try:
            conn = self._get_cloud_sql_connection()
            cur = conn.cursor()
            
            # Insert run
            cur.execute(
                "INSERT INTO runs (id, status) VALUES (%s, %s)",
                (run_id, "active")
            )
            
            # Insert event
            cur.execute(
                "INSERT INTO run_events (event_type, details) VALUES (%s, %s) RETURNING id, ts",
                ("CLOUD_RUN_COMPLETE", json.dumps({
                    "run_id": run_id,
                    "task": task,
                    "context": context,
                    "timestamp": timestamp,
                    "source": "CLOUD_RUN_NOVA"
                }))
            )
            event_id, ts = cur.fetchone()
            
            # Get counts
            cur.execute("SELECT COUNT(*) FROM run_events")
            event_count = cur.fetchone()[0]
            
            cur.execute("SELECT COUNT(*) FROM runs")
            run_count = cur.fetchone()[0]
            
            conn.commit()
            cur.close()
            conn.close()
            
            receipts["cloud_sql"] = {
                "status": "SUCCESS",
                "run_id": run_id,
                "event_id": event_id,
                "timestamp": str(ts)
            }
            counters["cloud_sql_events"] = event_count
            counters["cloud_sql_runs"] = run_count
            
        except Exception as e:
            receipts["cloud_sql"] = {"status": "ERROR", "error": str(e)}
            counters["cloud_sql_events"] = 0
        
        # 2. Redis/Dragonfly Queue
        try:
            r = redis.Redis(host=self.redis_host, port=self.redis_port, decode_responses=True)
            
            # Add to stream
            stream_id = r.xadd("nova:queue", {
                "run_id": run_id,
                "task": task,
                "timestamp": timestamp,
                "source": "CLOUD_RUN"
            })
            
            # Get queue length
            queue_len = r.xlen("nova:queue")
            
            # Also add to a simple list for visibility
            r.lpush("nova:tasks", json.dumps({
                "run_id": run_id,
                "task": task,
                "timestamp": timestamp
            }))
            
            receipts["redis"] = {
                "status": "SUCCESS",
                "stream_id": stream_id,
                "queue_length": queue_len
            }
            counters["redis_queue"] = queue_len
            
        except Exception as e:
            receipts["redis"] = {"status": "ERROR", "error": str(e)}
            counters["redis_queue"] = 0
        
        # 3. GCS - Write comprehensive artifact
        try:
            client = storage.Client(project=self.project_id)
            bucket = client.bucket(self.gcs_bucket)
            
            # Write main artifact
            blob_path = f"receipts/cloud_run/{run_id}.json"
            blob = bucket.blob(blob_path)
            
            artifact_content = json.dumps({
                "run_id": run_id,
                "task": task,
                "context": context,
                "timestamp": timestamp,
                "receipts": receipts,
                "counters": counters,
                "source": "CLOUD_RUN_NOVA"
            }, indent=2)
            
            blob.upload_from_string(artifact_content)
            
            # Also write a proof file
            proof_path = f"receipts/proof/proof_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            proof_blob = bucket.blob(proof_path)
            
            proof_content = json.dumps({
                "timestamp": timestamp,
                "run_id": run_id,
                "counters": counters,
                "success_rate": sum(1 for r in receipts.values() if r.get("status") == "SUCCESS") / max(len(receipts), 1) * 100
            }, indent=2)
            
            proof_blob.upload_from_string(proof_content)
            
            receipts["gcs"] = {
                "status": "SUCCESS",
                "artifact_path": f"gs://{self.gcs_bucket}/{blob_path}",
                "proof_path": f"gs://{self.gcs_bucket}/{proof_path}",
                "public_url": f"https://storage.googleapis.com/{self.gcs_bucket}/{blob_path}"
            }
            
        except Exception as e:
            receipts["gcs"] = {"status": "ERROR", "error": str(e)}
        
        # 4. Local PostgreSQL (if enabled)
        if self.local_pg_enabled:
            try:
                conn = psycopg2.connect(
                    host="127.0.0.1",
                    port=5432,
                    dbname="nova_db",
                    user="nova",
                    password="NovaP@ssw0rd!2025"
                )
                cur = conn.cursor()
                
                # Create simple tracking table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS cloud_run_events (
                        id SERIAL PRIMARY KEY,
                        run_id TEXT NOT NULL,
                        task TEXT,
                        created_at TIMESTAMP DEFAULT NOW()
                    )
                """)
                
                cur.execute(
                    "INSERT INTO cloud_run_events (run_id, task) VALUES (%s, %s)",
                    (run_id, task)
                )
                
                cur.execute("SELECT COUNT(*) FROM cloud_run_events")
                local_count = cur.fetchone()[0]
                
                conn.commit()
                cur.close()
                conn.close()
                
                receipts["local_pg"] = {
                    "status": "SUCCESS",
                    "events": local_count
                }
                counters["local_pg_events"] = local_count
                
            except Exception as e:
                receipts["local_pg"] = {"status": "ERROR", "error": str(e)}
                counters["local_pg_events"] = 0
        
        # Generate final proof
        proof = {
            "run_id": run_id,
            "timestamp": timestamp,
            "task": task,
            "receipts": receipts,
            "counters": counters,
            "deployment": "CLOUD_RUN",
            "success_rate": sum(1 for r in receipts.values() if r.get("status") == "SUCCESS") / len(receipts) * 100,
            "message": "Nova Orchestrator on Cloud Run - Complete Integration"
        }
        
        return proof

# Global orchestrator instance
orch = NovaOrchestrator()

@app.on_event("startup")
async def startup_event():
    """Initialize on startup"""
    print("✅ Nova Orchestrator started on Cloud Run")
    
    # Write startup event
    try:
        result = orch.execute_complete_run("CLOUD_RUN_STARTUP", {"event": "startup"})
        print(f"Startup receipt: {result.get('run_id')}")
    except Exception as e:
        print(f"Startup error: {e}")

@app.get("/")
async def root():
    return {
        "service": "Nova Orchestrator Complete",
        "deployment": "Cloud Run",
        "status": "operational",
        "databases": ["Cloud SQL", "Redis/Dragonfly", "GCS"],
        "endpoints": ["/health", "/execute", "/proof"]
    }

@app.get("/health")
async def health_check():
    """Health check with database connectivity test"""
    health = {}
    
    # Check Cloud SQL
    try:
        conn = orch._get_cloud_sql_connection()
        cur = conn.cursor()
        cur.execute("SELECT 1")
        cur.close()
        conn.close()
        health["cloud_sql"] = "healthy"
    except:
        health["cloud_sql"] = "unhealthy"
    
    # Check Redis
    try:
        r = redis.Redis(host=orch.redis_host, port=orch.redis_port)
        r.ping()
        health["redis"] = "healthy"
    except:
        health["redis"] = "unhealthy"
    
    # Check GCS
    try:
        client = storage.Client(project=orch.project_id)
        bucket = client.bucket(orch.gcs_bucket)
        list(bucket.list_blobs(max_results=1))
        health["gcs"] = "healthy"
    except:
        health["gcs"] = "unhealthy"
    
    health["overall"] = "healthy" if all(v == "healthy" for v in health.values()) else "degraded"
    
    return health

@app.post("/execute")
async def execute_task(request: TaskRequest):
    """Execute a complete task touching all databases"""
    try:
        result = orch.execute_complete_run(request.task, request.context)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/proof")
async def generate_proof():
    """Generate and return proof of all database operations"""
    try:
        result = orch.execute_complete_run(
            "PROOF_GENERATION",
            {"purpose": "verification", "timestamp": datetime.now().isoformat()}
        )
        
        # Write proof to GCS
        if result.get("receipts", {}).get("gcs", {}).get("status") == "SUCCESS":
            proof_url = result["receipts"]["gcs"].get("public_url", "")
            result["proof_url"] = proof_url
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))