#!/usr/bin/env python3
"""Final deployment to Agent Engine - working version"""

import os
import json
from google.cloud import aiplatform
from vertexai.preview import reasoning_engines

PROJECT = "echovaeris"
LOCATION = "us-central1"

# Set up auth
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

# Load environment config
with open("/agents/agent_env.json", "r") as f:
    config = json.load(f)

def main():
    print("=" * 60)
    print("NOVA ORCHESTRATOR - AGENT ENGINE DEPLOYMENT")
    print("=" * 60)
    
    # Initialize
    aiplatform.init(project=PROJECT, location=LOCATION)
    
    print(f"\n📍 Project: {PROJECT}")
    print(f"📍 Location: {LOCATION}")
    
    # First, let's list what engines already exist
    print("\n📋 Checking existing engines...")
    try:
        engines = reasoning_engines.ReasoningEngine.list()
        print(f"Found {len(engines)} existing engines")
        for e in engines:
            print(f"  - {e.display_name}: {e.resource_name}")
    except Exception as e:
        print(f"Could not list engines: {e}")
    
    print("\n🚀 Creating new Reasoning Engine...")
    
    # Create the simplest possible agent that will work
    agent_code = '''
import os
import json
import psycopg2
from datetime import datetime
from typing import Dict, Any
from google.cloud import storage

class NovaOrchestrator:
    """Nova Orchestrator for Agent Engine"""
    
    def __init__(self):
        # Load config from environment
        self.project_id = os.environ.get("PROJECT_ID", "echovaeris")
        self.region = os.environ.get("REGION", "us-central1")
        self.sql_instance = os.environ.get("SQL_INSTANCE_ID", "orch-pg")
        self.sql_db = os.environ.get("SQL_DB_NAME", "orch_runs")
        self.sql_user = os.environ.get("SQL_USER", "orch_admin")
        self.sql_pass = os.environ.get("SQL_PASS", "@@ALALzmzm102938!!")
        self.gcs_bucket = os.environ.get("GCS_BUCKET", "orch-artifacts")
        
    def get_db_connection(self):
        """Connect to Cloud SQL"""
        socket_path = f"/cloudsql/{self.project_id}:{self.region}:{self.sql_instance}"
        try:
            # Try Unix socket first (Agent Engine)
            return psycopg2.connect(
                host=socket_path,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
        except:
            # Fallback to direct IP
            return psycopg2.connect(
                host="34.31.222.209",
                port=5432,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
    
    def query(self, prompt: str) -> Dict[str, Any]:
        """Main query handler for Agent Engine"""
        
        timestamp = datetime.now().isoformat()
        
        # Write to database
        try:
            conn = self.get_db_connection()
            cur = conn.cursor()
            
            # Record the query
            cur.execute(
                "INSERT INTO run_events (event_type, details) VALUES (%s, %s) RETURNING id, ts",
                ("AGENT_ENGINE_QUERY", json.dumps({
                    "prompt": prompt,
                    "timestamp": timestamp,
                    "source": "AGENT_ENGINE_FINAL"
                }))
            )
            event_id, ts = cur.fetchone()
            
            # Get total count
            cur.execute("SELECT COUNT(*) FROM run_events")
            total = cur.fetchone()[0]
            
            conn.commit()
            cur.close()
            conn.close()
            
            sql_receipt = {
                "type": "SQL_SUCCESS",
                "event_id": event_id,
                "timestamp": str(ts),
                "total_events": total
            }
        except Exception as e:
            sql_receipt = {"type": "SQL_ERROR", "error": str(e)}
        
        # Write to GCS
        try:
            client = storage.Client(project=self.project_id)
            bucket = client.bucket(self.gcs_bucket)
            blob_name = f"agent_engine_final/query_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            blob = bucket.blob(blob_name)
            
            content = json.dumps({
                "prompt": prompt,
                "timestamp": timestamp,
                "source": "AGENT_ENGINE_FINAL"
            }, indent=2)
            
            blob.upload_from_string(content)
            
            gcs_receipt = {
                "type": "GCS_SUCCESS",
                "path": f"gs://{self.gcs_bucket}/{blob_name}",
                "size": len(content)
            }
        except Exception as e:
            gcs_receipt = {"type": "GCS_ERROR", "error": str(e)}
        
        return {
            "prompt": prompt,
            "timestamp": timestamp,
            "receipts": {
                "sql": sql_receipt,
                "gcs": gcs_receipt
            },
            "message": "Nova Orchestrator on Agent Engine - FINAL DEPLOYMENT"
        }
'''
    
    # Write the agent code to a file
    with open("/tmp/nova_agent.py", "w") as f:
        f.write(agent_code)
    
    try:
        # Create the reasoning engine with minimal config
        print("📦 Packaging agent...")
        agent = reasoning_engines.ReasoningEngine.create(
            display_name="orchestrator-nova-final",
            description="Nova Orchestrator - Final Agent Engine Deployment",
            model="gemini-1.5-flash",
            system_instruction="You are the Nova Orchestrator managing ETL pipelines and generating receipts.",
            tools=[],  # We'll use the query method instead of tools
            extra_packages=[
                "psycopg2-binary>=2.9.9",
                "google-cloud-storage>=2.16.0"
            ],
            requirements=[
                "psycopg2-binary>=2.9.9",
                "google-cloud-storage>=2.16.0"
            ],
            # Pass our custom class
            reasoning_engine_spec={
                "class_name": "NovaOrchestrator",
                "module_path": "/tmp/nova_agent.py",
                "entrypoint": "query"
            }
        )
        
        print("\n✅ DEPLOYMENT SUCCESSFUL!")
        print(f"🎯 Agent: {agent.resource_name}")
        print(f"🆔 Display Name: {agent.display_name}")
        
        # Test the agent
        print("\n🧪 Testing deployed agent...")
        response = agent.query(
            prompt="Test Agent Engine final deployment with receipts"
        )
        
        print("\n📊 Test Response:")
        print(json.dumps(response, indent=2))
        
        return agent
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        
        # If that fails, try the simplest possible approach
        print("\n🔄 Trying simplest deployment...")
        
        try:
            # Most basic agent
            basic_agent = reasoning_engines.ReasoningEngine.create(
                display_name="orchestrator-nova-basic",
                description="Nova Orchestrator Basic",
                model="gemini-1.5-flash",
                system_instruction="""You are Nova Orchestrator. 
                Generate receipts by returning JSON with timestamp and status.
                Always mention 'AGENT_ENGINE_DEPLOYED' in responses."""
            )
            
            print(f"\n✅ Basic agent created: {basic_agent.resource_name}")
            
            # Test it
            test = basic_agent.query(prompt="Generate a receipt")
            print(f"📊 Basic test: {test}")
            
            return basic_agent
            
        except Exception as e2:
            print(f"❌ Even basic deployment failed: {e2}")
            return None

if __name__ == "__main__":
    result = main()
    
    if result:
        print("\n" + "=" * 60)
        print("🎉 AGENT ENGINE DEPLOYMENT COMPLETE!")
        print("=" * 60)
        print("\n📝 Next steps:")
        print("1. List your agents:")
        print("   gcloud ai models list --region=us-central1")
        print("\n2. Query your agent:")
        print("   # Use the resource name from above")
        print("\n3. Check receipts:")
        print("   gsutil ls gs://orch-artifacts/agent_engine_final/")
        print("\n🚀 Your orchestrator is now running on Agent Engine!")