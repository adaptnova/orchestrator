#!/usr/bin/env python3
"""Proper Agent Engine deployment with code upload"""

import os
import shutil
import tempfile
from google.cloud import aiplatform
from vertexai.preview import reasoning_engines

PROJECT = "echovaeris"
LOCATION = "us-central1"

# Set up auth
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

def main():
    print("=" * 60)
    print("NOVA ORCHESTRATOR - AGENT ENGINE DEPLOYMENT")
    print("=" * 60)
    
    # Initialize
    aiplatform.init(project=PROJECT, location=LOCATION)
    
    print("\n📦 Preparing deployment package...")
    
    # Create a temp directory with our code
    with tempfile.TemporaryDirectory() as tmpdir:
        # Copy necessary files
        shutil.copy("/agents/orchestrator_core.py", tmpdir)
        shutil.copy("/agents/agent_entry.py", tmpdir)
        shutil.copy("/agents/requirements.txt", tmpdir)
        shutil.copy("/agents/agent_env.json", tmpdir)
        
        print(f"📂 Package prepared in {tmpdir}")
        print("📋 Files included:")
        for f in os.listdir(tmpdir):
            print(f"   - {f}")
        
        print("\n🚀 Deploying to Agent Engine...")
        
        try:
            # Deploy using the reasoning engines SDK
            agent = reasoning_engines.ReasoningEngine.create(
                display_name="orchestrator-nova",
                description="Nova Orchestrator with SQL/GCS receipts",
                reasoning_engine_type="REASONING_ENGINE",
                model="gemini-1.5-flash",  # or "gemini-1.5-pro"
                system_instruction="""You are the Nova Orchestrator. 
                You manage ETL pipelines and generate receipts for all operations.
                Always write to Cloud SQL and GCS to provide verifiable receipts.""",
                tools=[
                    {
                        "function_declarations": [
                            {
                                "name": "runs_record_event",
                                "description": "Record an event to Cloud SQL",
                                "parameters": {
                                    "type": "object",
                                    "properties": {
                                        "event_type": {"type": "string"},
                                        "details": {"type": "object"}
                                    },
                                    "required": ["event_type", "details"]
                                }
                            },
                            {
                                "name": "artifacts_write_text",
                                "description": "Write text artifact to GCS",
                                "parameters": {
                                    "type": "object",
                                    "properties": {
                                        "artifact_name": {"type": "string"},
                                        "content": {"type": "string"}
                                    },
                                    "required": ["artifact_name", "content"]
                                }
                            }
                        ]
                    }
                ],
                extra_packages=[
                    "google-cloud-storage>=2.16.0",
                    "psycopg2-binary>=2.9.9"
                ]
            )
            
            print("\n✅ DEPLOYMENT SUCCESSFUL!")
            print(f"🎯 Agent: {agent.resource_name}")
            
            # Test the agent
            print("\n🧪 Testing the deployed agent...")
            response = agent.query(
                prompt="Generate a test receipt to verify Agent Engine deployment"
            )
            
            print(f"📊 Response: {response}")
            
            return agent
            
        except Exception as e:
            print(f"\n❌ Deployment failed: {e}")
            
            # Try alternative approach
            print("\n🔄 Trying alternative deployment method...")
            return deploy_alternative()

def deploy_alternative():
    """Alternative deployment using raw API"""
    
    from google.cloud.aiplatform_v1beta1 import ReasoningEnginesServiceClient
    from google.cloud.aiplatform_v1beta1.types import (
        ReasoningEngine,
        ReasoningEngineSpec
    )
    
    client = ReasoningEnginesServiceClient(
        client_options={"api_endpoint": f"{LOCATION}-aiplatform.googleapis.com"}
    )
    
    parent = f"projects/{PROJECT}/locations/{LOCATION}"
    
    # Upload code to GCS first
    print("\n📤 Uploading code to GCS...")
    os.system("gsutil -m cp -r /agents/* gs://orch-artifacts/agent-engine-code/")
    
    # Create engine spec pointing to GCS
    spec = ReasoningEngineSpec(
        package_spec=ReasoningEngineSpec.PackageSpec(
            pickle_object_gcs_uri="gs://orch-artifacts/agent-engine-code/"
        )
    )
    
    engine = ReasoningEngine(
        display_name="orchestrator-nova-v2",
        description="Nova Orchestrator deployed from GCS",
        spec=spec
    )
    
    try:
        operation = client.create_reasoning_engine(
            parent=parent,
            reasoning_engine=engine
        )
        
        result = operation.result(timeout=300)
        print(f"\n✅ Alternative deployment successful!")
        print(f"🎯 Engine: {result.name}")
        return result
        
    except Exception as e:
        print(f"❌ Alternative also failed: {e}")
        return None

if __name__ == "__main__":
    result = main()
    
    if result:
        print("\n" + "=" * 60)
        print("🎉 AGENT ENGINE IS LIVE!")
        print("=" * 60)
        print("\n🔍 Verify with:")
        print("gcloud ai reasoning-engines list --region=us-central1")
        print("\n📊 Your receipts continue to:")
        print("   - Cloud SQL: orch-pg")
        print("   - GCS: gs://orch-artifacts/")