#!/usr/bin/env python3
"""Orchestrator Nova - Cloud Run Production Service with REAL RECEIPTS"""

import os
import json
import psycopg2
from datetime import datetime
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from google.cloud import storage

# Configuration from env vars
PROJECT_ID = os.environ.get("PROJECT_ID", "echovaeris")
REGION = os.environ.get("REGION", "us-central1")
SQL_INSTANCE_ID = os.environ.get("SQL_INSTANCE_ID", "orch-pg")
SQL_DB_NAME = os.environ.get("SQL_DB_NAME", "orch_runs")
SQL_USER = os.environ.get("SQL_USER", "orch_admin")
SQL_PASS = os.environ.get("SQL_PASS", "@@ALALzmzm102938!!")
GCS_BUCKET = os.environ.get("GCS_BUCKET", "orch-artifacts")

app = FastAPI(
    title="Orchestrator Nova",
    description="Cloud Run Service with REAL SQL & GCS Receipts",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TaskRequest(BaseModel):
    task: str
    context: Optional[Dict[str, Any]] = {}

class TaskResponse(BaseModel):
    task_id: str
    status: str
    receipts: Dict[str, Any]
    timestamp: str

def get_db_connection():
    """Get PostgreSQL connection using Cloud SQL Unix socket"""
    # Cloud Run provides the socket at /cloudsql/
    socket_path = f"/cloudsql/{PROJECT_ID}:{REGION}:{SQL_INSTANCE_ID}"
    
    return psycopg2.connect(
        host=socket_path,
        dbname=SQL_DB_NAME,
        user=SQL_USER,
        password=SQL_PASS
    )

def runs_record_event(event_type: str, details: Dict[str, Any]) -> Dict[str, Any]:
    """REAL database write with receipt"""
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Create table if not exists
        cur.execute("""
            CREATE TABLE IF NOT EXISTS run_events (
                id BIGSERIAL PRIMARY KEY,
                ts TIMESTAMP NOT NULL DEFAULT NOW(),
                event_type TEXT NOT NULL,
                details JSONB NOT NULL
            )
        """)
        
        # Insert event
        cur.execute(
            "INSERT INTO run_events (event_type, details) VALUES (%s, %s) RETURNING id, ts",
            (event_type, json.dumps(details))
        )
        event_id, timestamp = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()
        
        return {
            "receipt": "SQL_WRITE",
            "event_id": event_id,
            "timestamp": str(timestamp),
            "event_type": event_type
        }
    except Exception as e:
        return {"receipt": "SQL_ERROR", "error": str(e)}

def artifacts_write_text(artifact_name: str, content: str) -> Dict[str, Any]:
    """REAL GCS write with receipt"""
    try:
        client = storage.Client(project=PROJECT_ID)
        bucket = client.bucket(GCS_BUCKET)
        blob_path = f"runs/{artifact_name}.txt"
        blob = bucket.blob(blob_path)
        blob.upload_from_string(content)
        
        return {
            "receipt": "GCS_WRITE",
            "artifact_name": artifact_name,
            "gcs_path": f"gs://{GCS_BUCKET}/{blob_path}",
            "size": len(content)
        }
    except Exception as e:
        return {"receipt": "GCS_ERROR", "error": str(e)}

@app.get("/")
async def root():
    return {
        "service": "Orchestrator Nova",
        "platform": "Cloud Run",
        "status": "operational",
        "receipts": "SQL + GCS enabled"
    }

@app.get("/health")
async def health_check():
    """Health with SQL connectivity test"""
    sql_test = runs_record_event("HEALTH_CHECK", {"platform": "Cloud Run"})
    
    return {
        "status": "healthy",
        "sql_connected": sql_test.get("receipt") == "SQL_WRITE",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/demo")
async def demo():
    """Demo that ACTUALLY writes receipts"""
    timestamp = datetime.now().isoformat()
    
    # Write to SQL
    sql_receipt = runs_record_event("DEMO_RUN", {
        "message": "Cloud Run demo with real receipts",
        "timestamp": timestamp
    })
    
    # Write to GCS
    gcs_receipt = artifacts_write_text(
        f"demo_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        f"Demo run at {timestamp} from Cloud Run"
    )
    
    return {
        "message": "✅ REAL RECEIPTS GENERATED!",
        "sql_receipt": sql_receipt,
        "gcs_receipt": gcs_receipt,
        "verify_sql": f"SELECT * FROM run_events WHERE id = {sql_receipt.get('event_id', 0)}",
        "verify_gcs": gcs_receipt.get("gcs_path", ""),
        "timestamp": timestamp
    }

@app.post("/execute", response_model=TaskResponse)
async def execute_task(request: TaskRequest, background_tasks: BackgroundTasks):
    """Execute with receipts"""
    task_id = f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # SQL receipt for task start
    sql_receipt = runs_record_event("TASK_START", {
        "task_id": task_id,
        "task": request.task,
        "context": request.context
    })
    
    # GCS receipt for task data
    gcs_receipt = artifacts_write_text(
        f"tasks/{task_id}",
        json.dumps({"task": request.task, "context": request.context})
    )
    
    return TaskResponse(
        task_id=task_id,
        status="executed",
        receipts={
            "sql": sql_receipt,
            "gcs": gcs_receipt
        },
        timestamp=datetime.now().isoformat()
    )

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
