# Nova Orchestrator - Cloud Run Deployment

## Architecture Benefits

### Current Setup (Working!)
- **Public Access**: ✅ http://34.171.63.140:8000
- **Load Balancer**: https://34.117.228.129 (SSL provisioning)
- **Bare Metal Power**: 96 cores, 720GB RAM, 6TB NVMe

### Cloud Run Enhancement (Next Level)
```
Internet → Cloud Run (Auto-scaling) → xxx VM (Processing)
         ↓                           ↓
    nova-orchestrator.run.app    High-performance backend
    nova-voice.run.app           6TB storage via NFS
    nova-data.run.app            AlloyDB/Redis
    nova-ml.run.app              GPU processing
```

## Why This Architecture Rocks

1. **Auto-scaling Excellence**
   - Scale to 0: $0 when idle
   - Scale to 1000+: Handle any spike
   - Per-service scaling: Independent agents

2. **Enterprise Features Free**
   - Automatic HTTPS/SSL
   - DDoS protection (Cloud Armor)
   - Global load balancing
   - Blue-green deployments

3. **Perfect Agent Isolation**
   - Each agent deploys independently
   - Language agnostic (Python, Go, Node.js)
   - Automatic rollback on failure
   - A/B testing native

4. **Cost Efficiency**
   - Pay per 100ms execution
   - 2M free requests/month
   - No over-provisioning
   - Spot pricing available

## Deployment Strategy

### Phase 1: Core Orchestrator (nova-orchestrator)
- Main API gateway
- Task routing
- Authentication

### Phase 2: Specialized Agents
- nova-voice: Gemini Live integration
- nova-data: ETL and analytics
- nova-ml: Model inference
- nova-security: Monitoring

### Phase 3: Advanced Features
- WebSockets for real-time
- gRPC for inter-service
- Pub/Sub for async
- Workflows for orchestration

## Quick Deploy Commands

```bash
# Deploy to Cloud Run
gcloud run deploy nova-orchestrator \
  --source . \
  --region us-central1 \
  --allow-unauthenticated

# Get URL
gcloud run services describe nova-orchestrator \
  --region us-central1 \
  --format "value(status.url)"
```

## xxx VM Integration

The xxx VM becomes the powerful backend:
- Persistent storage (6TB NVMe RAID0)
- High-compute tasks (96 cores)
- Database connections (AlloyDB/Redis)
- NFS mount: `10.128.0.6:/lssd`

Cloud Run agents communicate with xxx via:
- Private Service Connect
- VPC connector
- Direct internal IPs
