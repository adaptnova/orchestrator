#!/usr/bin/env python3
"""Agent Engine Entry Point for Orchestrator Nova"""

import os
import json
from typing import Dict, Any, List, Optional
from google.cloud.aiplatform_v1beta1 import ReasoningEngine

# Import our orchestrator core
from orchestrator_core import (
    Orchestrator,
    runs_record_event,
    artifacts_write_text,
    init_database
)

class NovaReasoningEngine:
    """Nova Orchestrator as a Reasoning Engine"""
    
    def __init__(self):
        """Initialize the reasoning engine"""
        self.orchestrator = Orchestrator()
        self.tools = self._get_tools()
        
    def _get_tools(self) -> List[Dict[str, Any]]:
        """Define tools available to the agent"""
        return [
            {
                "name": "runs_record_event",
                "description": "Record an event to the database with receipt",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "event_type": {
                            "type": "string",
                            "description": "Type of event (e.g., PLAN, ACT, COMPLETE)"
                        },
                        "details": {
                            "type": "object",
                            "description": "Event details as JSON object"
                        }
                    },
                    "required": ["event_type", "details"]
                }
            },
            {
                "name": "artifacts_write_text",
                "description": "Write text artifact to GCS with receipt",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "artifact_name": {
                            "type": "string",
                            "description": "Name for the artifact"
                        },
                        "content": {
                            "type": "string",
                            "description": "Text content to store"
                        }
                    },
                    "required": ["artifact_name", "content"]
                }
            },
            {
                "name": "execute_task",
                "description": "Execute a complete task with planning and acting",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Task description to execute"
                        }
                    },
                    "required": ["task"]
                }
            }
        ]
    
    def reason(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Main reasoning entry point for Agent Engine"""
        
        # Record the query
        query_receipt = runs_record_event("AGENT_QUERY", {
            "query": query,
            "context": context or {},
            "source": "AGENT_ENGINE"
        })
        
        # Determine the appropriate action
        if "record" in query.lower() or "event" in query.lower():
            # Direct event recording
            result = runs_record_event("USER_EVENT", {
                "description": query,
                "context": context
            })
            
        elif "write" in query.lower() or "artifact" in query.lower():
            # Artifact writing
            result = artifacts_write_text(
                f"user_artifact",
                query
            )
            
        else:
            # Full task execution
            result = self.orchestrator.execute(query)
        
        # Record completion
        completion_receipt = runs_record_event("AGENT_COMPLETE", {
            "query": query,
            "result_summary": {
                "type": result.get("receipt_type", "execution"),
                "status": "success" if "SUCCESS" in str(result) else "completed"
            }
        })
        
        return {
            "query": query,
            "result": result,
            "receipts": {
                "query": query_receipt,
                "completion": completion_receipt
            },
            "message": "Task processed by Nova Agent Engine!"
        }
    
    def __call__(self, query: str, **kwargs) -> Dict[str, Any]:
        """Make the engine callable"""
        return self.reason(query, kwargs.get("context"))

# Agent Engine entrypoint - MUST return the agent object
def get_app():
    """Agent Engine entrypoint - returns the agent instance"""
    return NovaReasoningEngine()

# Backwards compatibility
def create_agent():
    """Factory function for Agent Engine"""
    return get_app()

# For direct testing
if __name__ == "__main__":
    engine = get_app()
    
    # Test the engine
    test_result = engine.reason("Test the orchestrator from Agent Engine")
    print(json.dumps(test_result, indent=2))
    
    # Test event recording
    event_result = engine.reason("Record a test event for verification")
    print(json.dumps(event_result, indent=2))