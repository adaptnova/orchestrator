# Orchestrator Nova Network Integration Requirements

## Current Mesh Network Discovery
- **Project**: echovaeris
- **Mesh Networks Identified**:
  - app-mesh-a (10.128.0.0/18) - High-performance Zone A with MTU 8896
  - app-mesh-b (10.129.0.0/18) - Zone B
  - app-mesh-c (10.130.0.0/18) - Zone C  
  - central-mgmt (10.0.0.0/16) - Management network
- **Multi-Project Setup**: 20 VPCs across 4 projects (expanding)

## Orchestrator Network Requirements

### 1. Service Placement
- **AlloyDB Cluster**: Needs VPC peering or Private Service Connect
- **Orchestrator Service**: Requires access to:
  - AlloyDB (database operations)
  - Redis/Memorystore (queuing)
  - Cloud Storage (artifacts)
  - Vertex AI APIs (agent operations)
  - Gemini API (voice interactions)

### 2. Network Access Patterns
```yaml
ingress:
  - voice_api: "Gemini Live webhook callbacks"
  - agent_api: "Vertex AI Agent Engine calls"
  - monitoring: "Health checks and metrics"
  
egress:
  - gcp_apis: "*.googleapis.com"
  - database: "AlloyDB cluster endpoint"
  - cache: "Redis endpoint"
  - storage: "GCS buckets"
```

### 3. Security Requirements
- Private IP communication within mesh
- Service account authentication
- No public exposure except through approved endpoints
- Network segmentation between zones

## Questions for GCP Engineer

1. **Preferred Network Placement**:
   - Should orchestrator join `central-mgmt` for management operations?
   - Or dedicated orchestrator network with peering to all meshes?
   - Which mesh zone (A/B/C) for primary placement?

2. **Cross-Project Access**:
   - How are the 4 projects connected? (Shared VPC, VPC peering, Private Service Connect?)
   - Service account delegation strategy across projects?
   - DNS resolution across project boundaries?

3. **AlloyDB Integration**:
   - Should we use Private Service Connect for AlloyDB?
   - Or VPC peering with allocated IP ranges?
   - Backup connectivity through which network?

4. **Load Balancing & HA**:
   - Multi-region failover requirements?
   - Internal load balancer placement?
   - Traffic routing between mesh zones?

5. **Expansion Considerations**:
   - Reserved IP ranges for future growth?
   - Network capacity planning (current MTU 8896 noted)
   - Integration points for new VPCs being added?

## Proposed Architecture Options

### Option A: Central Management Integration
```
central-mgmt (10.0.0.0/16)
    ├── orchestrator-subnet (10.0.1.0/24)
    ├── alloydb-peering (10.0.2.0/24)
    └── peerings to app-mesh-[a,b,c]
```

### Option B: Dedicated Orchestrator Network
```
orchestrator-vpc (10.131.0.0/18)
    ├── compute-subnet (10.131.0.0/24)
    ├── services-subnet (10.131.1.0/24)
    └── peerings to all 20 VPCs
```

### Option C: Mesh-Native Deployment
```
app-mesh-a (primary)
    └── orchestrator in existing subnet
app-mesh-b (standby)
    └── orchestrator replica
app-mesh-c (dr)
    └── disaster recovery
```

## Next Steps
1. Review network requirements with GCP engineer
2. Determine optimal placement strategy
3. Configure VPC peering/Private Service Connect
4. Set up firewall rules and routes
5. Deploy orchestrator with proper network config
6. Test cross-network connectivity

## Contact Points Needed
- GCP Network Engineer contact
- Network architecture documentation
- Firewall rule templates
- DNS configuration standards
- Service mesh policies
