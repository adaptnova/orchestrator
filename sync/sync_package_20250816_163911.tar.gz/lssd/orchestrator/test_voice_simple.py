#!/usr/bin/env python3
"""Simple test of voice orchestration without Gemini API."""

import sys
import os
from pathlib import Path

# Set up path
sys.path.insert(0, str(Path(__file__).parent))

# Set up credentials
sa_key_path = Path("sa-key.json")
if sa_key_path.exists():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(sa_key_path.absolute())

from src.voice.voice_orchestrator import VoiceOrchestrator
import asyncio

async def test_direct_functions():
    """Test orchestrator functions directly without Gemini."""
    print("Testing Voice Orchestrator Functions Directly\n")
    
    orchestrator = VoiceOrchestrator()
    
    # Test 1: Check status
    print("1. Testing check_status...")
    result = await orchestrator.check_status()
    print(f"   Result: {result['message']}\n")
    
    # Test 2: Run ETL
    print("2. Testing run_etl...")
    result = await orchestrator.run_etl("test_pipeline", {"source": "voice_test"})
    print(f"   Result: {result['message']}")
    print(f"   Job ID: {result.get('job_id')}\n")
    
    # Test 3: Create artifact
    print("3. Testing create_artifact...")
    result = await orchestrator.create_artifact(
        "voice_test",
        "This artifact was created by voice command test"
    )
    print(f"   Result: {result['message']}")
    print(f"   URI: {result.get('gs_uri')}\n")
    
    # Test 4: Execute task
    print("4. Testing execute_task...")
    result = await orchestrator.execute_task("Process voice test workflow")
    print(f"   Result: {result['message']}")
    print(f"   Steps completed: {result.get('steps_completed')}\n")
    
    print("✅ All direct function tests completed successfully!")

if __name__ == "__main__":
    asyncio.run(test_direct_functions())