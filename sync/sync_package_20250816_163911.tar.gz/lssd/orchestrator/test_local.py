#!/usr/bin/env python3
"""Quick test script for local development."""

import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.orchestrator import Orchestrator, runs_record_event, artifacts_write_text, etl_run_job

def test_tools():
    """Test individual tools."""
    print("Testing tools...")
    
    # Test ETL job (this should work without infrastructure)
    try:
        result = etl_run_job({"test": True})
        print(f"✓ ETL job test: {result['status']}")
    except Exception as e:
        print(f"✗ ETL job test failed: {e}")
    
    # Test orchestrator planning
    try:
        import asyncio
        orchestrator = Orchestrator()
        plan = asyncio.run(orchestrator.plan("test bootstrap"))
        print(f"✓ Orchestrator planning: {len(plan['steps'])} steps")
    except Exception as e:
        print(f"✗ Orchestrator planning failed: {e}")
    
    print("\nTo test database and storage:")
    print("  1. Run: make bootstrap")
    print("  2. Run: make test")

if __name__ == "__main__":
    test_tools()