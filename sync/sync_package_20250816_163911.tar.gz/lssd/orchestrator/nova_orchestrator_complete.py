#!/usr/bin/env python3
"""Nova Orchestrator Complete - All Databases Integration"""

import os
import json
import psycopg2
import redis
from datetime import datetime
from typing import Dict, Any, List
from google.cloud import storage
import requests
import hashlib
import uuid

class NovaOrchestratorComplete:
    """Complete orchestrator touching all databases"""
    
    def __init__(self):
        # Configuration
        self.project_id = "echovaeris"
        self.region = "us-central1"
        self.gcs_bucket = "orch-artifacts"
        
        # Cloud SQL (primary)
        self.sql_instance = "orch-pg"
        self.sql_db = "orch_runs"
        self.sql_user = "orch_admin"
        self.sql_pass = "@@ALALzmzm102938!!"
        
        # Local PostgreSQL with pgvector
        self.local_pg_host = "127.0.0.1"
        self.local_pg_db = "nova_db"
        self.local_pg_user = "nova"
        self.local_pg_pass = "NovaP@ssw0rd!2025"
        
        # Dragonfly (Redis compatible)
        self.dragonfly_host = "127.0.0.1"
        self.dragonfly_port = 6379
        
        # Qdrant vector DB
        self.qdrant_host = "127.0.0.1"
        self.qdrant_port = 6333
        
        # JanusGraph
        self.janusgraph_host = "127.0.0.1"
        self.janusgraph_port = 8182
        
        # ScyllaDB (for JanusGraph CQL)
        self.scylla_host = "127.0.0.1"
        self.scylla_port = 9042
        
        self.init_databases()
    
    def init_databases(self):
        """Initialize all database connections and tables"""
        # Cloud SQL
        try:
            conn = self._get_cloud_sql_connection()
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS run_events (
                    id BIGSERIAL PRIMARY KEY,
                    ts TIMESTAMP NOT NULL DEFAULT NOW(),
                    event_type TEXT NOT NULL,
                    details JSONB NOT NULL
                );
                CREATE TABLE IF NOT EXISTS runs (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    created_at TIMESTAMP DEFAULT NOW(),
                    status TEXT DEFAULT 'pending'
                );
                CREATE TABLE IF NOT EXISTS artifacts (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    run_id UUID REFERENCES runs(id),
                    path TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT NOW()
                );
            """)
            conn.commit()
            cur.close()
            conn.close()
        except Exception as e:
            print(f"Cloud SQL init error: {e}")
        
        # Local PostgreSQL with pgvector
        try:
            conn = psycopg2.connect(
                host=self.local_pg_host,
                port=5432,
                dbname=self.local_pg_db,
                user=self.local_pg_user,
                password=self.local_pg_pass
            )
            cur = conn.cursor()
            cur.execute("""
                CREATE EXTENSION IF NOT EXISTS vector;
                CREATE TABLE IF NOT EXISTS embeddings (
                    id SERIAL PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    embedding vector(1536),
                    created_at TIMESTAMP DEFAULT NOW()
                );
            """)
            conn.commit()
            cur.close()
            conn.close()
        except Exception as e:
            print(f"Local PG init error: {e}")
    
    def _get_cloud_sql_connection(self):
        """Get Cloud SQL connection"""
        socket_path = f"/cloudsql/{self.project_id}:{self.region}:{self.sql_instance}"
        try:
            return psycopg2.connect(
                host=socket_path,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
        except:
            # Fallback to direct IP
            return psycopg2.connect(
                host="34.31.222.209",
                port=5432,
                dbname=self.sql_db,
                user=self.sql_user,
                password=self.sql_pass
            )
    
    def execute_complete_run(self, task: str) -> Dict[str, Any]:
        """Execute a complete run touching all databases"""
        
        run_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        receipts = {}
        
        # 1. Cloud SQL - Insert run and event
        try:
            conn = self._get_cloud_sql_connection()
            cur = conn.cursor()
            
            # Insert run
            cur.execute(
                "INSERT INTO runs (id, status) VALUES (%s, %s)",
                (run_id, "active")
            )
            
            # Insert event
            cur.execute(
                "INSERT INTO run_events (event_type, details) VALUES (%s, %s) RETURNING id",
                ("COMPLETE_RUN", json.dumps({
                    "run_id": run_id,
                    "task": task,
                    "timestamp": timestamp,
                    "source": "NOVA_COMPLETE"
                }))
            )
            event_id = cur.fetchone()[0]
            
            # Get counts
            cur.execute("SELECT COUNT(*) FROM run_events")
            event_count = cur.fetchone()[0]
            
            cur.execute("SELECT COUNT(*) FROM runs")
            run_count = cur.fetchone()[0]
            
            conn.commit()
            cur.close()
            conn.close()
            
            receipts["cloud_sql"] = {
                "status": "SUCCESS",
                "run_id": run_id,
                "event_id": event_id,
                "total_events": event_count,
                "total_runs": run_count
            }
        except Exception as e:
            receipts["cloud_sql"] = {"status": "ERROR", "error": str(e)}
        
        # 2. Dragonfly - Add to queue
        try:
            r = redis.Redis(host=self.dragonfly_host, port=self.dragonfly_port, decode_responses=True)
            
            # Add to stream
            stream_id = r.xadd("nova:queue", {
                "run_id": run_id,
                "task": task,
                "timestamp": timestamp
            })
            
            # Get queue length
            queue_len = r.xlen("nova:queue")
            
            receipts["dragonfly"] = {
                "status": "SUCCESS",
                "stream_id": stream_id,
                "queue_length": queue_len
            }
        except Exception as e:
            receipts["dragonfly"] = {"status": "ERROR", "error": str(e)}
        
        # 3. JanusGraph - Create graph edge
        try:
            # Gremlin query to add edge
            query = {
                "gremlin": f"""
                    g.addV('run').property('id', '{run_id}').as('r')
                     .addV('artifact').property('path', 'artifact_{run_id}').as('a')
                     .addE('writes').from('r').to('a')
                     .property('timestamp', '{timestamp}')
                """
            }
            
            response = requests.post(
                f"http://{self.janusgraph_host}:{self.janusgraph_port}",
                json=query,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                # Count edges
                count_query = {"gremlin": "g.E().hasLabel('writes').count()"}
                count_resp = requests.post(
                    f"http://{self.janusgraph_host}:{self.janusgraph_port}",
                    json=count_query
                )
                
                edge_count = count_resp.json().get("result", {}).get("data", [0])[0] if count_resp.status_code == 200 else "unknown"
                
                receipts["janusgraph"] = {
                    "status": "SUCCESS",
                    "edge_created": True,
                    "total_edges": edge_count
                }
            else:
                receipts["janusgraph"] = {
                    "status": "ERROR",
                    "error": f"HTTP {response.status_code}"
                }
        except Exception as e:
            receipts["janusgraph"] = {"status": "ERROR", "error": str(e)}
        
        # 4. Qdrant - Store vector
        try:
            # Create test embedding (1536 dims)
            embedding = [0.1 * (i % 10) for i in range(1536)]
            
            # Upsert to Qdrant
            payload = {
                "points": [
                    {
                        "id": hashlib.md5(run_id.encode()).hexdigest()[:8],
                        "vector": embedding,
                        "payload": {
                            "run_id": run_id,
                            "task": task,
                            "timestamp": timestamp
                        }
                    }
                ]
            }
            
            response = requests.put(
                f"http://{self.qdrant_host}:{self.qdrant_port}/collections/nova_mem/points",
                json=payload
            )
            
            if response.status_code in [200, 201]:
                # Get collection info
                info_resp = requests.get(
                    f"http://{self.qdrant_host}:{self.qdrant_port}/collections/nova_mem"
                )
                
                vector_count = info_resp.json().get("result", {}).get("vectors_count", 0)
                
                receipts["qdrant"] = {
                    "status": "SUCCESS",
                    "vector_stored": True,
                    "total_vectors": vector_count
                }
            else:
                receipts["qdrant"] = {
                    "status": "ERROR",
                    "error": f"HTTP {response.status_code}"
                }
        except Exception as e:
            receipts["qdrant"] = {"status": "ERROR", "error": str(e)}
        
        # 5. Local PostgreSQL with pgvector
        try:
            conn = psycopg2.connect(
                host=self.local_pg_host,
                port=5432,
                dbname=self.local_pg_db,
                user=self.local_pg_user,
                password=self.local_pg_pass
            )
            cur = conn.cursor()
            
            # Store embedding
            embedding_str = "[" + ",".join([str(0.1 * (i % 10)) for i in range(1536)]) + "]"
            cur.execute(
                "INSERT INTO embeddings (run_id, embedding) VALUES (%s, %s)",
                (run_id, embedding_str)
            )
            
            # Get count
            cur.execute("SELECT COUNT(*) FROM embeddings")
            embedding_count = cur.fetchone()[0]
            
            conn.commit()
            cur.close()
            conn.close()
            
            receipts["local_pg"] = {
                "status": "SUCCESS",
                "embedding_stored": True,
                "total_embeddings": embedding_count
            }
        except Exception as e:
            receipts["local_pg"] = {"status": "ERROR", "error": str(e)}
        
        # 6. GCS - Write artifact
        try:
            client = storage.Client(project=self.project_id)
            bucket = client.bucket(self.gcs_bucket)
            blob_path = f"receipts/complete_run_{run_id}.json"
            blob = bucket.blob(blob_path)
            
            artifact_content = json.dumps({
                "run_id": run_id,
                "task": task,
                "timestamp": timestamp,
                "receipts": receipts
            }, indent=2)
            
            blob.upload_from_string(artifact_content)
            
            receipts["gcs"] = {
                "status": "SUCCESS",
                "path": f"gs://{self.gcs_bucket}/{blob_path}",
                "size_bytes": len(artifact_content),
                "public_url": f"https://storage.googleapis.com/{self.gcs_bucket}/{blob_path}"
            }
        except Exception as e:
            receipts["gcs"] = {"status": "ERROR", "error": str(e)}
        
        # 7. ScyllaDB check (for future JanusGraph backend)
        try:
            from cassandra.cluster import Cluster
            cluster = Cluster([self.scylla_host])
            session = cluster.connect()
            
            # Check keyspace
            rows = session.execute("SELECT keyspace_name FROM system_schema.keyspaces WHERE keyspace_name = 'janusgraph'")
            
            receipts["scylladb"] = {
                "status": "SUCCESS",
                "janusgraph_keyspace": len(list(rows)) > 0
            }
            
            cluster.shutdown()
        except Exception as e:
            receipts["scylladb"] = {"status": "ERROR", "error": str(e)}
        
        # Generate proof
        proof = {
            "run_id": run_id,
            "timestamp": timestamp,
            "task": task,
            "receipts": receipts,
            "counters": {
                "cloud_sql_events": receipts.get("cloud_sql", {}).get("total_events", 0),
                "dragonfly_queue": receipts.get("dragonfly", {}).get("queue_length", 0),
                "janusgraph_edges": receipts.get("janusgraph", {}).get("total_edges", 0),
                "qdrant_vectors": receipts.get("qdrant", {}).get("total_vectors", 0),
                "local_pg_embeddings": receipts.get("local_pg", {}).get("total_embeddings", 0)
            },
            "success_rate": sum(1 for r in receipts.values() if r.get("status") == "SUCCESS") / len(receipts) * 100
        }
        
        return proof

if __name__ == "__main__":
    print("Nova Orchestrator Complete - Testing all databases...")
    orch = NovaOrchestratorComplete()
    result = orch.execute_complete_run("Test complete database integration")
    print(json.dumps(result, indent=2))