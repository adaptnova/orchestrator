#!/usr/bin/env python3
"""Orchestrator Core for Agent Engine"""

import os
import json
import psycopg2
from datetime import datetime
from typing import Dict, Any
from google.cloud import storage

# Get config from env
PROJECT_ID = os.environ.get("PROJECT_ID", "echovaeris")
REGION = os.environ.get("REGION", "us-central1")
SQL_INSTANCE_ID = os.environ.get("SQL_INSTANCE_ID", "orch-pg")
SQL_DB_NAME = os.environ.get("SQL_DB_NAME", "orch_runs")
SQL_USER = os.environ.get("SQL_USER", "orch_admin")
SQL_PASS = os.environ.get("SQL_PASS", "@@ALALzmzm102938!!")
GCS_BUCKET = os.environ.get("GCS_BUCKET", "orch-artifacts")

def get_db_connection():
    """Connect using Cloud SQL Unix socket (works in Agent Engine)"""
    socket_path = f"/cloudsql/{PROJECT_ID}:{REGION}:{SQL_INSTANCE_ID}"
    
    try:
        # Try Unix socket first (Agent Engine)
        return psycopg2.connect(
            host=socket_path,
            dbname=SQL_DB_NAME,
            user=SQL_USER,
            password=SQL_PASS
        )
    except:
        # Fallback to direct IP (for testing)
        return psycopg2.connect(
            host="34.31.222.209",
            port=5432,
            dbname=SQL_DB_NAME,
            user=SQL_USER,
            password=SQL_PASS
        )

def init_database():
    """Initialize database tables"""
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS run_events (
                id BIGSERIAL PRIMARY KEY,
                ts TIMESTAMP NOT NULL DEFAULT NOW(),
                event_type TEXT NOT NULL,
                details JSONB NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_event_type ON run_events(event_type);
            CREATE INDEX IF NOT EXISTS idx_ts ON run_events(ts DESC);
        """)
        conn.commit()
        cur.close()
        conn.close()
        return True
    except Exception as e:
        print(f"DB init error: {e}")
        return False

def runs_record_event(event_type: str, details: Dict[str, Any]) -> Dict[str, Any]:
    """Write event to database - REAL receipt"""
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        cur.execute(
            "INSERT INTO run_events (event_type, details) VALUES (%s, %s) RETURNING id, ts",
            (event_type, json.dumps(details))
        )
        event_id, timestamp = cur.fetchone()
        conn.commit()
        
        cur.execute("SELECT COUNT(*) FROM run_events")
        total_events = cur.fetchone()[0]
        
        cur.close()
        conn.close()
        
        return {
            "receipt_type": "SQL_WRITE_SUCCESS",
            "event_id": event_id,
            "timestamp": str(timestamp),
            "event_type": event_type,
            "total_events_in_db": total_events,
            "source": "AGENT_ENGINE"
        }
    except Exception as e:
        return {
            "receipt_type": "SQL_WRITE_FAILED",
            "error": str(e)
        }

def artifacts_write_text(artifact_name: str, content: str) -> Dict[str, Any]:
    """Write artifact to GCS - REAL receipt"""
    try:
        client = storage.Client(project=PROJECT_ID)
        bucket = client.bucket(GCS_BUCKET)
        blob_path = f"agent_engine/{artifact_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        blob = bucket.blob(blob_path)
        blob.upload_from_string(content)
        
        return {
            "receipt_type": "GCS_WRITE_SUCCESS",
            "artifact_name": artifact_name,
            "gcs_path": f"gs://{GCS_BUCKET}/{blob_path}",
            "size_bytes": len(content),
            "source": "AGENT_ENGINE"
        }
    except Exception as e:
        return {
            "receipt_type": "GCS_WRITE_FAILED",
            "error": str(e)
        }

class Orchestrator:
    """Main orchestrator class"""
    
    def __init__(self):
        self.name = "Nova Orchestrator"
        self.version = "Agent Engine 1.0"
        init_database()
        
    def plan(self, task: str) -> Dict[str, Any]:
        """Plan task execution"""
        plan_receipt = runs_record_event("PLAN", {
            "task": task,
            "engine": "AGENT_ENGINE",
            "timestamp": datetime.now().isoformat()
        })
        
        return {
            "task": task,
            "steps": ["analyze", "execute", "verify"],
            "receipt": plan_receipt
        }
    
    def act(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute planned task"""
        # Write SQL receipt
        sql_receipt = runs_record_event("ACT", {
            "plan": plan,
            "engine": "AGENT_ENGINE",
            "timestamp": datetime.now().isoformat()
        })
        
        # Write GCS receipt
        gcs_receipt = artifacts_write_text(
            "agent_engine_act",
            json.dumps(plan, indent=2)
        )
        
        return {
            "status": "completed",
            "sql_receipt": sql_receipt,
            "gcs_receipt": gcs_receipt,
            "engine": "AGENT_ENGINE"
        }
    
    def execute(self, task: str) -> Dict[str, Any]:
        """Main execution entry point"""
        plan = self.plan(task)
        result = self.act(plan)
        
        # Final receipt
        final_receipt = runs_record_event("COMPLETE", {
            "task": task,
            "result": result,
            "engine": "AGENT_ENGINE"
        })
        
        return {
            "task": task,
            "plan": plan,
            "result": result,
            "final_receipt": final_receipt,
            "message": "Task executed in Agent Engine!"
        }
