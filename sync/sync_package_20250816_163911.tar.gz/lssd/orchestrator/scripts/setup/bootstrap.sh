#!/usr/bin/env bash
# Bootstrap script for Agents GCP Infrastructure
# Project: echovaeris
# Lead: Chase

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Load environment variables
if [ -f ".claude/projects/agents-gcp/.env" ]; then
    set -a; source .claude/projects/agents-gcp/.env; set +a
else
    echo -e "${RED}Error: .env file not found${NC}"
    exit 1
fi

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}     Agents GCP Infrastructure Bootstrap         ${NC}"
echo -e "${BLUE}==================================================${NC}"
echo ""
echo -e "Project ID: ${GREEN}${PROJECT_ID}${NC}"
echo -e "Region: ${GREEN}${REGION}${NC}"
echo -e "Organization: ${GREEN}${ORG_NAME}${NC}"
echo ""

# Function to check if a command succeeded
check_status() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $1"
    else
        echo -e "${RED}✗${NC} $1"
        exit 1
    fi
}

# Function to check if resource exists
resource_exists() {
    local resource_type=$1
    local resource_name=$2
    local check_command=$3
    
    if eval "$check_command" &>/dev/null; then
        echo -e "${YELLOW}⚠${NC} $resource_type '$resource_name' already exists, skipping..."
        return 0
    else
        return 1
    fi
}

echo -e "${YELLOW}Step 1: Setting project context...${NC}"
gcloud config set project "$PROJECT_ID" &>/dev/null
check_status "Project set to $PROJECT_ID"

gcloud config set compute/region "$REGION" &>/dev/null
check_status "Region set to $REGION"

gcloud config set ai/region "$REGION" &>/dev/null || true
check_status "AI region set to $REGION"

echo ""
echo -e "${YELLOW}Step 2: Enabling required APIs...${NC}"
apis=(
    "aiplatform.googleapis.com"
    "generativelanguage.googleapis.com"
    "agentbuilder.googleapis.com"
    "storage.googleapis.com"
    "iam.googleapis.com"
    "cloudresourcemanager.googleapis.com"
    "sqladmin.googleapis.com"
    "redis.googleapis.com"
    "run.googleapis.com"
    "cloudbuild.googleapis.com"
    "logging.googleapis.com"
    "monitoring.googleapis.com"
    "dialogflow.googleapis.com"
    "secretmanager.googleapis.com"
)

for api in "${apis[@]}"; do
    echo -n "Enabling $api... "
    if gcloud services enable "$api" --quiet 2>/dev/null; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${YELLOW}already enabled${NC}"
    fi
done

echo ""
echo -e "${YELLOW}Step 3: Creating service accounts...${NC}"

# Orchestrator service account
if ! resource_exists "Service account" "$ORCH_SA_EMAIL" \
    "gcloud iam service-accounts describe $ORCH_SA_EMAIL"; then
    gcloud iam service-accounts create "$ORCH_SA_ID" \
        --display-name="${ORG_NAME} Orchestrator Nova" \
        --quiet
    check_status "Created orchestrator service account"
fi

# Agent builder service account
if ! resource_exists "Service account" "$AGENT_SA_EMAIL" \
    "gcloud iam service-accounts describe $AGENT_SA_EMAIL"; then
    gcloud iam service-accounts create "$AGENT_SA_ID" \
        --display-name="${ORG_NAME} Agent Builder" \
        --quiet
    check_status "Created agent builder service account"
fi

echo ""
echo -e "${YELLOW}Step 4: Granting IAM roles...${NC}"

roles=(
    "roles/aiplatform.admin"
    "roles/storage.admin"
    "roles/cloudsql.client"
    "roles/redis.admin"
    "roles/run.admin"
    "roles/iam.serviceAccountTokenCreator"
    "roles/logging.admin"
    "roles/secretmanager.accessor"
)

for role in "${roles[@]}"; do
    echo -n "Granting $role... "
    gcloud projects add-iam-policy-binding "$PROJECT_ID" \
        --member="serviceAccount:${ORCH_SA_EMAIL}" \
        --role="$role" \
        --quiet &>/dev/null
    echo -e "${GREEN}✓${NC}"
done

echo ""
echo -e "${YELLOW}Step 5: Creating storage buckets...${NC}"

# Main orchestrator bucket
if ! gsutil ls -p "$PROJECT_ID" | grep -q "gs://${GCS_BUCKET}/"; then
    gsutil mb -p "$PROJECT_ID" -l "$REGION" "gs://${GCS_BUCKET}"
    check_status "Created orchestrator bucket: gs://${GCS_BUCKET}"
fi

# Artifact bucket
ARTIFACT_BUCKET_NAME="agent-artifacts-${PROJECT_ID}"
if ! gsutil ls -p "$PROJECT_ID" | grep -q "gs://${ARTIFACT_BUCKET_NAME}/"; then
    gsutil mb -p "$PROJECT_ID" -l "$REGION" "gs://${ARTIFACT_BUCKET_NAME}"
    check_status "Created artifact bucket: gs://${ARTIFACT_BUCKET_NAME}"
fi

# Model bucket
MODEL_BUCKET_NAME="agent-models-${PROJECT_ID}"
if ! gsutil ls -p "$PROJECT_ID" | grep -q "gs://${MODEL_BUCKET_NAME}/"; then
    gsutil mb -p "$PROJECT_ID" -l "$REGION" "gs://${MODEL_BUCKET_NAME}"
    check_status "Created model bucket: gs://${MODEL_BUCKET_NAME}"
fi

echo ""
echo -e "${YELLOW}Step 6: Creating Cloud SQL instance...${NC}"

if ! resource_exists "Cloud SQL instance" "$SQL_INSTANCE_ID" \
    "gcloud sql instances describe $SQL_INSTANCE_ID"; then
    echo "Creating Cloud SQL instance (this may take 5-10 minutes)..."
    gcloud sql instances create "$SQL_INSTANCE_ID" \
        --database-version=POSTGRES_15 \
        --cpu=2 \
        --memory=7680MB \
        --region="$REGION" \
        --no-assign-ip \
        --root-password="$SQL_PASS" \
        --quiet
    check_status "Created Cloud SQL instance: $SQL_INSTANCE_ID"
    
    # Create user
    gcloud sql users create "$SQL_USER" \
        --instance="$SQL_INSTANCE_ID" \
        --password="$SQL_PASS" \
        --quiet
    check_status "Created database user: $SQL_USER"
    
    # Create database
    gcloud sql databases create "$SQL_DB_NAME" \
        --instance="$SQL_INSTANCE_ID" \
        --quiet
    check_status "Created database: $SQL_DB_NAME"
fi

echo ""
echo -e "${YELLOW}Step 7: Creating Redis instance...${NC}"

if ! resource_exists "Redis instance" "$REDIS_NAME" \
    "gcloud redis instances describe $REDIS_NAME --region=$REGION"; then
    echo "Creating Redis instance (this may take 5-10 minutes)..."
    gcloud redis instances create "$REDIS_NAME" \
        --size=1 \
        --region="$REGION" \
        --tier=BASIC \
        --quiet
    check_status "Created Redis instance: $REDIS_NAME"
    
    # Get Redis host IP
    REDIS_HOST=$(gcloud redis instances describe "$REDIS_NAME" \
        --region="$REGION" \
        --format="value(host)")
    echo -e "${GREEN}Redis host IP: $REDIS_HOST${NC}"
    
    # Update .env file with Redis host
    sed -i "s/REDIS_HOST=\"\"/REDIS_HOST=\"$REDIS_HOST\"/" .claude/projects/agents-gcp/.env
    check_status "Updated .env with Redis host"
fi

echo ""
echo -e "${YELLOW}Step 8: Creating Secret Manager entries...${NC}"

# Store SQL password in Secret Manager
if ! gcloud secrets describe sql-password &>/dev/null; then
    echo -n "$SQL_PASS" | gcloud secrets create sql-password \
        --data-file=- \
        --replication-policy="automatic" \
        --quiet
    check_status "Created secret: sql-password"
    
    # Grant access to orchestrator service account
    gcloud secrets add-iam-policy-binding sql-password \
        --member="serviceAccount:${ORCH_SA_EMAIL}" \
        --role="roles/secretmanager.secretAccessor" \
        --quiet
    check_status "Granted secret access to orchestrator"
fi

echo ""
echo -e "${YELLOW}Step 9: Setting up VPC connector (for Cloud Run)...${NC}"

CONNECTOR_NAME="orchestrator-connector"
if ! gcloud compute networks vpc-access connectors describe "$CONNECTOR_NAME" \
    --region="$REGION" &>/dev/null; then
    gcloud compute networks vpc-access connectors create "$CONNECTOR_NAME" \
        --region="$REGION" \
        --subnet-project="$PROJECT_ID" \
        --subnet="default" \
        --quiet
    check_status "Created VPC connector: $CONNECTOR_NAME"
fi

echo ""
echo -e "${YELLOW}Step 10: Creating initial directories in storage...${NC}"

# Create directory structure in GCS
gsutil -m mkdir -p \
    "gs://${GCS_BUCKET}/runs/" \
    "gs://${GCS_BUCKET}/artifacts/" \
    "gs://${GCS_BUCKET}/logs/" \
    "gs://${ARTIFACT_BUCKET_NAME}/etl/" \
    "gs://${ARTIFACT_BUCKET_NAME}/processed/" \
    "gs://${MODEL_BUCKET_NAME}/checkpoints/" \
    "gs://${MODEL_BUCKET_NAME}/deployed/" \
    2>/dev/null || true
check_status "Created storage directory structure"

echo ""
echo -e "${GREEN}==================================================${NC}"
echo -e "${GREEN}        Bootstrap Completed Successfully!         ${NC}"
echo -e "${GREEN}==================================================${NC}"
echo ""
echo -e "${BLUE}Summary:${NC}"
echo -e "  • Project: ${GREEN}$PROJECT_ID${NC}"
echo -e "  • Service Account: ${GREEN}$ORCH_SA_EMAIL${NC}"
echo -e "  • Storage Bucket: ${GREEN}gs://$GCS_BUCKET${NC}"
echo -e "  • Cloud SQL: ${GREEN}$SQL_INSTANCE_ID${NC}"
echo -e "  • Redis: ${GREEN}$REDIS_NAME${NC}"
if [ ! -z "${REDIS_HOST:-}" ]; then
    echo -e "  • Redis Host: ${GREEN}$REDIS_HOST${NC}"
fi
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo -e "  1. Test database connectivity: ${BLUE}make ssh-sql${NC}"
echo -e "  2. Run orchestrator locally: ${BLUE}make run-local${NC}"
echo -e "  3. Deploy to Cloud Run: ${BLUE}make deploy-dev${NC}"
echo ""