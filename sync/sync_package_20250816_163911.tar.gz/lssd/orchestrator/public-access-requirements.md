# Orchestrator Nova - Public Access Requirements

## Current Status
- ✅ Orchestrator running on xxx VM (10.128.0.7)
- ✅ Service listening on port 8000
- ✅ Systemd service: orchestrator.service
- ✅ NFS export available at /lssd

## Requirements for Public Access

### 1. Firewall Rule
```yaml
name: orchestrator-public-https
network: app-mesh-a
direction: INGRESS
priority: 1000
source_ranges: 0.0.0.0/0
target_tags: orchestrator-public
rules:
  - tcp:443 (for HTTPS)
  - tcp:80 (for redirect)
```

### 2. Load Balancer Setup
- External Application Load Balancer
- Backend service pointing to xxx VM:8000
- Health check on /health endpoint
- SSL certificate for HTTPS

### 3. DNS Subdomain Options
```
orchestrator.echovaeris.com
api.echovaeris.com  
nova.echovaeris.com
agent.echovaeris.com
```

### 4. Alternative: Cloud Run Proxy
If direct exposure isn't preferred, we could:
- Deploy a Cloud Run service as public proxy
- Cloud Run forwards to xxx VM via Private Service Connect
- Automatic HTTPS and scaling

## What I Can Provide

Once network access is configured, I can:
1. Update the orchestrator to handle HTTPS headers
2. Add authentication/API keys
3. Implement rate limiting
4. Add CORS for specific domains
5. Set up monitoring and logging

## Quick Test Commands

Once public access is enabled:
```bash
# Test health endpoint
curl https://orchestrator.echovaeris.com/health

# Test demo endpoint  
curl https://orchestrator.echovaeris.com/demo

# Execute task
curl -X POST https://orchestrator.echovaeris.com/execute \
  -H "Content-Type: application/json" \
  -d '{"task": "test", "context": {}}'
```
