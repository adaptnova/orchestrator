#!/bin/bash
set -e

echo "=========================================="
echo "NOVA ORCHESTRATOR - COMPLETE DB SETUP"
echo "=========================================="

# 1. PostgreSQL with pgvector
echo -e "\n[1/4] Installing PostgreSQL with pgvector..."
sudo apt-get update
sudo apt-get install -y postgresql-15 postgresql-client-15 postgresql-contrib postgresql-15-pgvector

# Create user and database
sudo -u postgres psql -c "CREATE ROLE nova WITH LOGIN PASSWORD 'NovaP@ssw0rd!2025';" || echo "User exists"
sudo -u postgres psql -c "CREATE DATABASE nova_db OWNER nova;" || echo "DB exists"
sudo -u postgres psql -d nova_db -c "CREATE EXTENSION IF NOT EXISTS vector;"

# Test PostgreSQL
PGPASSWORD='NovaP@ssw0rd!2025' psql -h 127.0.0.1 -U nova -d nova_db -c "SELECT extname FROM pg_extension WHERE extname='vector';" && echo "✅ PostgreSQL with pgvector ready"

# 2. Qdrant Vector DB
echo -e "\n[2/4] Installing Qdrant..."
sudo useradd -r -s /usr/sbin/nologin qdrant || echo "User exists"
sudo mkdir -p /var/lib/qdrant /etc/qdrant

# Download Qdrant binary
if [ ! -f /usr/local/bin/qdrant ]; then
    curl -L -o /usr/local/bin/qdrant https://github.com/qdrant/qdrant/releases/download/v1.8.3/qdrant-x86_64-unknown-linux-gnu
    sudo chmod +x /usr/local/bin/qdrant
fi

# Create config
sudo tee /etc/qdrant/config.yaml >/dev/null <<'CFG'
storage:
  path: "/var/lib/qdrant"
cluster:
  enabled: false
service:
  http_port: 6333
  grpc_port: 6334
CFG

# Create systemd service
sudo tee /etc/systemd/system/qdrant.service >/dev/null <<'UNIT'
[Unit]
Description=Qdrant Vector DB
After=network.target

[Service]
User=qdrant
Group=qdrant
WorkingDirectory=/var/lib/qdrant
ExecStart=/usr/local/bin/qdrant --storage /var/lib/qdrant --config /etc/qdrant/config.yaml
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
UNIT

# Fix permissions and start
sudo chown -R qdrant:qdrant /var/lib/qdrant
sudo systemctl daemon-reload
sudo systemctl enable --now qdrant

# Wait for startup
sleep 5

# Create collection
curl -s -X PUT http://127.0.0.1:6333/collections/nova_mem \
  -H 'Content-Type: application/json' \
  -d '{"vectors":{"size":1536,"distance":"Cosine"}}' | jq . && echo "✅ Qdrant ready"

# 3. ScyllaDB
echo -e "\n[3/4] Installing ScyllaDB..."

# Add repo
if [ ! -f /etc/apt/sources.list.d/scylla.list ]; then
    curl -s https://repositories.scylladb.com/scylla/repo/ubuntu/scylladb-6.2.list | sudo tee /etc/apt/sources.list.d/scylla.list
    curl -s https://repositories.scylladb.com/scylla/repo-key.gpg | sudo apt-key add -
fi

sudo apt-get update
sudo apt-get install -y scylla scylla-tools scylla-jmx || echo "ScyllaDB might already be installed"

# Setup ScyllaDB (non-interactive)
sudo /usr/lib/scylla/scylla_setup --no-raid-setup --no-ntp-setup --no-ec2-check --no-kernel-check --no-verify-package --no-enable-service || echo "Setup might be done"

# Start services
sudo systemctl enable --now scylla-server || echo "ScyllaDB already running"
sudo systemctl enable --now scylla-jmx || echo "JMX already running"

# Wait for ScyllaDB to be ready
echo "Waiting for ScyllaDB..."
for i in {1..30}; do
    if nodetool status 2>/dev/null | grep -q "UN"; then
        break
    fi
    sleep 2
done

# Create keyspace
cqlsh -e "CREATE KEYSPACE IF NOT EXISTS janusgraph WITH replication = {'class':'SimpleStrategy','replication_factor':1};" && echo "✅ ScyllaDB ready"

# 4. Verify Dragonfly and JanusGraph (should already be running)
echo -e "\n[4/4] Verifying existing services..."

# Check Dragonfly
redis-cli ping && echo "✅ Dragonfly responding"

# Check JanusGraph
curl -s http://localhost:8182 | grep -q "Gremlin" && echo "✅ JanusGraph responding" || echo "⚠️ JanusGraph not responding"

echo -e "\n=========================================="
echo "DATABASE SETUP COMPLETE!"
echo "=========================================="
echo "Services running:"
echo "  - PostgreSQL (local): 5432"
echo "  - Qdrant: 6333"
echo "  - ScyllaDB: 9042"
echo "  - Dragonfly: 6379"
echo "  - JanusGraph: 8182"
echo ""
echo "Test with: python3 /lssd/orchestrator/nova_orchestrator_complete.py"