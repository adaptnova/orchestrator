#!/usr/bin/env python3
"""Simple deployment to Agent Engine using gcloud SDK"""

import os
import sys
import json
import subprocess

# Set up auth
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

# Load config
with open("/agents/agent_env.json", "r") as f:
    config = json.load(f)

PROJECT_ID = config["PROJECT_ID"]
REGION = config["REGION"]

print("=" * 60)
print("NOVA ORCHESTRATOR - AGENT ENGINE DEPLOYMENT")
print("=" * 60)

# First, let's check if APIs are enabled
print("\n📋 Checking APIs...")
subprocess.run([
    "gcloud", "services", "enable",
    "aiplatform.googleapis.com",
    "storage.googleapis.com",
    "sqladmin.googleapis.com",
    "--project", PROJECT_ID
])

# Upload our code to GCS for deployment
print("\n📦 Packaging code for deployment...")

# Create a deployment package
package_dir = "/tmp/agent_package"
os.makedirs(package_dir, exist_ok=True)

# Copy files
subprocess.run(["cp", "/agents/orchestrator_core.py", f"{package_dir}/"])
subprocess.run(["cp", "/agents/agent_entry.py", f"{package_dir}/"])
subprocess.run(["cp", "/agents/requirements.txt", f"{package_dir}/"])
subprocess.run(["cp", "/agents/agent_env.json", f"{package_dir}/"])

# Create main.py entry point
main_content = """#!/usr/bin/env python3
import os
import json

# Load config
with open("agent_env.json", "r") as f:
    config = json.load(f)
    for key, value in config.items():
        os.environ[key] = value

from agent_entry import NovaReasoningEngine

# Initialize the agent
agent = NovaReasoningEngine()

def handler(request):
    \"\"\"Cloud Function handler for Agent Engine\"\"\"
    query = request.get("query", "test")
    context = request.get("context", {})
    
    result = agent.reason(query, context)
    return result
"""

with open(f"{package_dir}/main.py", "w") as f:
    f.write(main_content)

# Create a tarball
print("\n📤 Creating deployment package...")
subprocess.run([
    "tar", "-czf", "/tmp/agent_package.tar.gz",
    "-C", package_dir, "."
])

# Upload to GCS
print("\n☁️ Uploading to GCS...")
subprocess.run([
    "gsutil", "cp", "/tmp/agent_package.tar.gz",
    f"gs://{config['GCS_BUCKET']}/agent-engine/agent_package.tar.gz"
])

print("\n✅ Package uploaded to GCS!")
print(f"📦 Location: gs://{config['GCS_BUCKET']}/agent-engine/agent_package.tar.gz")

# Create a simple test script
print("\n🧪 Creating test script...")

test_script = f"""#!/usr/bin/env python3
import sys
sys.path.insert(0, '{package_dir}')

# Set env vars
import os
with open('{package_dir}/agent_env.json', 'r') as f:
    import json
    config = json.load(f)
    for k, v in config.items():
        os.environ[k] = v

# Test the agent locally
from agent_entry import NovaReasoningEngine

agent = NovaReasoningEngine()
result = agent.reason("Test the orchestrator from Agent Engine deployment")

import json
print(json.dumps(result, indent=2))
"""

with open("/tmp/test_agent.py", "w") as f:
    f.write(test_script)

print("\n🧪 Testing agent locally...")
result = subprocess.run(
    ["python3", "/tmp/test_agent.py"],
    capture_output=True,
    text=True
)

if result.returncode == 0:
    print("✅ Agent test successful!")
    print("📊 Test output:")
    print(result.stdout)
else:
    print("❌ Agent test failed:")
    print(result.stderr)

print("\n" + "=" * 60)
print("📝 NEXT STEPS:")
print("=" * 60)
print("\n1. Deploy using Vertex AI console:")
print(f"   - Go to: https://console.cloud.google.com/vertex-ai/generative/reasoning-engines?project={PROJECT_ID}")
print("   - Click 'Create Reasoning Engine'")
print(f"   - Use package: gs://{config['GCS_BUCKET']}/agent-engine/agent_package.tar.gz")
print("   - Entry point: main.handler")
print("\n2. Or deploy via gcloud (when available):")
print(f"   gcloud ai reasoning-engines create \\")
print(f"     --display-name='orchestrator-nova' \\")
print(f"     --region={REGION} \\")
print(f"     --source=gs://{config['GCS_BUCKET']}/agent-engine/agent_package.tar.gz")
print("\n3. Test deployment:")
print(f"   gcloud ai reasoning-engines query REASONING_ENGINE_ID \\")
print(f"     --region={REGION} \\")
print(f"     --query='Generate a test receipt'")
print("\n📊 Receipts will be written to:")
print(f"   - Cloud SQL: {config['SQL_INSTANCE_ID']}")
print(f"   - GCS: gs://{config['GCS_BUCKET']}/")
print("\n🎉 ORCHESTRATOR IS READY FOR AGENT ENGINE!")