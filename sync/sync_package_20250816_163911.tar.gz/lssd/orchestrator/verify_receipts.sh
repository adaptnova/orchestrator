#!/bin/bash
# Verification script for REAL receipts

echo "=== 🔍 ORCHESTRATOR RECEIPT VERIFICATION ==="
echo ""

# Get Cloud Run URL
URL=$(gcloud run services describe orchestrator-nova --region us-central1 --format "value(status.url)" 2>/dev/null)

if [ -z "$URL" ]; then
  echo "⏳ Cloud Run deployment still in progress..."
  echo "Run this script again in 1-2 minutes"
  exit 1
fi

echo "✅ Cloud Run URL: $URL"
echo ""

# Test demo endpoint (this writes REAL receipts)
echo "1. Hitting demo endpoint to generate receipts..."
RESPONSE=$(curl -s "$URL/demo")
echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"

# Extract event ID from response
EVENT_ID=$(echo "$RESPONSE" | grep -o '"event_id": [0-9]*' | grep -o '[0-9]*' | head -1)

echo ""
echo "2. Verifying SQL receipt (event_id: $EVENT_ID)..."
gcloud sql connect orch-pg --user=orch_admin --database=orch_runs --project=echovaeris \
  --command="SELECT id, ts, event_type, details->>'message' as message FROM run_events WHERE id = ${EVENT_ID:-0} OR event_type = 'DEMO_RUN' ORDER BY id DESC LIMIT 5;" 2>/dev/null || echo "SQL verification pending..."

echo ""
echo "3. Verifying GCS receipts..."
gsutil ls -l gs://orch-artifacts/runs/demo_* 2>/dev/null | head -5 || echo "GCS verification pending..."

echo ""
echo "=== 📊 RECEIPT SUMMARY ==="
echo "Cloud Run URL: $URL"
echo "Swagger UI: $URL/docs"
echo "Demo endpoint: $URL/demo"
echo ""
echo "To manually verify:"
echo "  SQL: gcloud sql connect orch-pg --user=orch_admin --database=orch_runs"
echo "  GCS: gsutil ls gs://orch-artifacts/runs/"
