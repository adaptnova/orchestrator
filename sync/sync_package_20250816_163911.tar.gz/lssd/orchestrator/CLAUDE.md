# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**Project Lead**: Chase  
**Project Name**: echovaeris (GCP Project ID)  
**Purpose**: Building and managing AI agents on Google Cloud Platform using Vertex AI, Dialogflow CX, and Gemini Live API

## Architecture Overview

This repository implements the **Orchestrator Nova** - a voice-enabled AI orchestrator that manages ETL pipelines, training jobs, and agent deployments on GCP. The architecture follows a managed-services-first approach using:

- **Vertex AI Agent Engine**: For agent deployment and management
- **Dialogflow CX**: For conversational interfaces
- **Gemini Live API**: For voice interactions
- **Cloud SQL (Postgres)**: For run metadata and state management
- **Memorystore (Redis)**: For queues and distributed locks
- **Cloud Storage**: For artifacts and model storage

## Essential Commands

### Project Setup & Authentication
```bash
# Set GCP project context
gcloud config set project echovaeris
gcloud config set ai/region us-central1
gcloud auth application-default login

# Check current authentication
gcloud auth list
gcloud config get-value project
```

### Bootstrap Infrastructure
```bash
# Source environment variables (from .claude/projects/agents-gcp/.env)
source .claude/projects/agents-gcp/.env

# Run bootstrap script from playbook
bash /agents/zero_to_orchestrator_day_1_playbook_gcp_voice_nova_bootstrap.md
# (Extract and run the bootstrap script section)
```

### Vertex AI Agent Operations
```bash
# List agents
gcloud ai agents list --location=us-central1

# Create orchestrator agent
gcloud ai agents create \
  --display-name="orchestrator-nova" \
  --location=us-central1 \
  --agent-type=conversational

# Deploy agent
gcloud ai endpoints deploy-model ENDPOINT_ID \
  --region=us-central1 \
  --model=MODEL_ID \
  --machine-type=n1-standard-4
```

### Development Workflow
```bash
# Install dependencies (when pyproject.toml exists)
pip install -e .

# Run orchestrator locally
python adk_app.py

# Test agent tools
python -c "from adk_app import runs_record_event; print(runs_record_event('TEST', {'msg': 'test'}))"
```

### Monitoring & Debugging
```bash
# View logs
gcloud logging read "resource.type=aiplatform.googleapis.com" --limit=50

# Check SQL connection
gcloud sql instances describe orch-pg --format="value(connectionName)"

# Test webhook
curl -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  https://us-central1-aiplatform.googleapis.com/v1/projects/echovaeris/locations/us-central1/endpoints
```

## Project Structure

```
/agents/
├── .claude/projects/agents-gcp/     # Project-specific configuration
│   ├── .env                        # Environment variables and secrets
│   ├── vertex-ai-reference.md      # Vertex AI command reference
│   └── dialogflow-reference.md     # Dialogflow CX reference
├── zero_to_orchestrator_day_1_playbook_gcp_voice_nova_bootstrap.md  # Main setup guide
├── orchestrator/                    # Orchestrator implementation (to be created)
│   ├── pyproject.toml              # Python dependencies
│   ├── adk_app.py                  # Main orchestrator with tools
│   └── voice_handler.py            # Gemini Live API integration
└── CLAUDE.md                        # This file
```

## Key Implementation Details

### Tool Architecture
The orchestrator implements side-effect-producing tools that write to real infrastructure:
- `runs_record_event`: Writes to Postgres for run tracking
- `artifacts_write_text`: Persists artifacts to Cloud Storage
- `etl_echo_job`: Placeholder for ETL job execution (replace with real implementation)

### Database Schema
```sql
-- Run events table (auto-created by adk_app.py)
CREATE TABLE run_events (
  id BIGSERIAL PRIMARY KEY,
  ts TIMESTAMP NOT NULL,
  event_type TEXT NOT NULL,
  details JSONB NOT NULL
);
```

### Service Account Requirements
The orchestrator service account needs these IAM roles:
- `roles/aiplatform.admin`: For Vertex AI operations
- `roles/storage.admin`: For artifact storage
- `roles/cloudsql.client`: For database access
- `roles/redis.admin`: For cache/queue operations

## Development Guidelines

### When Adding New Tools
1. Implement idempotent operations with clear receipts
2. Add proper error handling and logging
3. Write to Postgres for audit trail
4. Return structured JSON responses
5. Document in function docstrings

### When Modifying Infrastructure
1. Update bootstrap script if adding new GCP services
2. Add new environment variables to `.env`
3. Document gcloud commands in appropriate reference file
4. Test locally before deploying to Agent Engine

### Security Considerations
- Never commit secrets directly - use `.env` locally and Secret Manager in production
- Service accounts follow least-privilege principle
- All webhooks require authentication
- Enable audit logging for all operations

## Common Tasks

### Deploy a New Agent Version
```bash
# 1. Test locally
python adk_app.py

# 2. Build and push to Agent Engine
gcloud ai agents versions create \
  --agent=orchestrator-nova \
  --location=us-central1 \
  --display-name="v1.0.0"

# 3. Promote to production
gcloud ai agents versions promote VERSION_ID \
  --agent=orchestrator-nova \
  --location=us-central1
```

### Add Voice Capabilities
```bash
# Update agent with voice config
gcloud ai agents update orchestrator-nova \
  --location=us-central1 \
  --update-voice-config='{
    "voice_model": "gemini-1.5-flash-latest",
    "enable_streaming": true
  }'
```

### Connect to Cloud SQL
```bash
# Use Cloud SQL Proxy for local development
cloud_sql_proxy -instances=echovaeris:us-central1:orch-pg=tcp:5432

# In Python code, use Unix socket in GCP
conn_str = f"host=/cloudsql/{PROJECT_ID}:{REGION}:{SQL_INSTANCE_ID} dbname={SQL_DB_NAME} user={SQL_USER} password={SQL_PASS}"
```

## Troubleshooting

### Authentication Issues
- Ensure `gcloud auth list` shows correct account
- Check service account has necessary IAM roles
- Verify `GOOGLE_APPLICATION_CREDENTIALS` if using service account key

### Database Connection Errors
- Check Cloud SQL instance is running: `gcloud sql instances list`
- Verify network connectivity (VPC, firewall rules)
- Use Cloud SQL Proxy for local development

### Agent Not Responding
- Check agent deployment status: `gcloud ai agents describe AGENT_ID`
- Review logs: `gcloud logging read "resource.labels.agent_id=AGENT_ID"`
- Verify webhook URL is accessible

## Next Steps (Per Playbook)

1. **Complete Bootstrap**: Run the bootstrap script to create all GCP resources
2. **Test Orchestrator**: Run `adk_app.py` to verify tool execution
3. **Add Voice**: Integrate Gemini Live API for voice control
4. **Deploy to Agent Engine**: Wrap orchestrator as Vertex AI agent
5. **Replace ETL Tool**: Implement real job runner with idempotent execution
6. **Add Monitoring**: Set up Cloud Trace and metrics collection
7. **Implement Gates**: Add policy enforcement and rollback capabilities

## Resources

- [Vertex AI Documentation](https://cloud.google.com/vertex-ai/docs)
- [Dialogflow CX Guide](https://cloud.google.com/dialogflow/cx/docs)
- [Gemini API Reference](https://ai.google.dev/api/rest)
- Project Config: `.claude/projects/agents-gcp/.env`
- Vertex AI Reference: `.claude/projects/agents-gcp/vertex-ai-reference.md`
- Dialogflow Reference: `.claude/projects/agents-gcp/dialogflow-reference.md`