#!/usr/bin/env python3
"""Deploy Orchestrator Nova to Agent Engine programmatically"""

import os
import sys
from google.cloud import aiplatform

# This is the v1beta1 API for Reasoning Engines
from google.cloud.aiplatform_v1beta1 import ReasoningEnginesServiceClient
from google.cloud.aiplatform_v1beta1.types import ReasoningEngine

PROJECT = "echovaeris"
LOCATION = "us-central1"
SA = "orchestrator-nova-sa@echovaeris.iam.gserviceaccount.com"

# Must match a real callable in your repo: module:function
ENTRYPOINT = "agent_entry:get_app"   # agent_entry.py -> def get_app(): return NovaReasoningEngine()

# Files in /agents directory
REQS_PATH = "/agents/requirements.txt"
ENV_VARS_PATH = "/agents/agent_env.json"

# Set up auth
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/tmp/sa-key.json"

def main():
    print("=" * 60)
    print("NOVA ORCHESTRATOR - AGENT ENGINE DEPLOYMENT")
    print("=" * 60)
    
    print(f"\n📍 Project: {PROJECT}")
    print(f"📍 Location: {LOCATION}")
    print(f"📍 Service Account: {SA}")
    print(f"📍 Entrypoint: {ENTRYPOINT}")
    
    # Initialize
    aiplatform.init(project=PROJECT, location=LOCATION)
    
    # Create client
    client = ReasoningEnginesServiceClient(
        client_options={"api_endpoint": f"{LOCATION}-aiplatform.googleapis.com"}
    )
    parent = f"projects/{PROJECT}/locations/{LOCATION}"
    
    print("\n📦 Creating Reasoning Engine package spec...")
    
    # Create the engine with proper package spec
    engine = ReasoningEngine(
        display_name="orchestrator-nova",
        description="Nova Orchestrator with SQL and GCS receipts - deployed via SDK",
        spec=ReasoningEngine.Spec(
            package_spec=ReasoningEngine.Spec.PackageSpec(
                # This tells Agent Engine how to find and run your code
                python_version="3.11",  # Specify Python version
                required_python_libraries=[
                    "google-cloud-aiplatform>=1.68.0",
                    "google-cloud-storage>=2.16.0", 
                    "psycopg2-binary>=2.9.9",
                    "requests>=2.32.3",
                    "fastapi>=0.116.0",
                    "uvicorn>=0.35.0",
                    "pydantic>=2.10.0"
                ]
            ),
            # The actual code files
            class_methods=[
                ReasoningEngine.Spec.ClassMethod(
                    # This is the method signature
                    method_name="reason",
                    # Input/output schema (optional but helps with validation)
                )
            ]
        )
    )
    
    print("\n🚀 Deploying to Agent Engine...")
    print("⏳ This may take a few minutes...")
    
    try:
        # Create the reasoning engine
        operation = client.create_reasoning_engine(
            parent=parent, 
            reasoning_engine=engine
        )
        
        print(f"📋 Operation: {operation.operation.name}")
        print("⏳ Waiting for deployment to complete...")
        
        # Wait for completion (timeout after 5 minutes)
        result = operation.result(timeout=300)
        
        print("\n✅ DEPLOYMENT SUCCESSFUL!")
        print(f"🎯 Agent Name: {result.name}")
        print(f"🆔 Resource ID: {result.name.split('/')[-1]}")
        
        # Extract the ID for querying
        engine_id = result.name.split('/')[-1]
        
        print("\n📝 Test your agent with:")
        print(f"gcloud ai reasoning-engines query {engine_id} \\")
        print(f"  --region={LOCATION} \\")
        print(f"  --query='Generate a production receipt'")
        
        print("\n📊 Or use the query script:")
        print(f"python3 query_agent_engine.py {engine_id}")
        
        return result
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        print(f"💡 Error details: {str(e)}")
        
        # Check if it's a permission issue
        if "permission" in str(e).lower():
            print("\n🔐 IAM Fix needed:")
            print(f"gcloud projects add-iam-policy-binding {PROJECT} \\")
            print(f"  --member='serviceAccount:{SA}' \\")
            print("  --role='roles/aiplatform.user'")
            
        return None

if __name__ == "__main__":
    result = main()
    
    if result:
        print("\n" + "=" * 60)
        print("🎉 AGENT ENGINE DEPLOYMENT COMPLETE!")
        print("=" * 60)
        print("\n📊 Your orchestrator is now running as a managed agent")
        print("💾 Receipts will continue writing to:")
        print(f"   - Cloud SQL: orch-pg")
        print(f"   - GCS: gs://orch-artifacts/")
        print("\n🚀 No more VM management needed!")
    else:
        print("\n⚠️ Check the error above and try again")