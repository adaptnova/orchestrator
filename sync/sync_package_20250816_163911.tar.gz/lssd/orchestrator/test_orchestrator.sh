#!/bin/bash
# Copy-paste this into Cloud Shell

echo "Testing Orchestrator Nova from Cloud Shell..."

# Test health
echo "1. Health Check:"
curl http://34.171.63.140:8000/health

# Test demo
echo -e "\n2. Demo Endpoint:"
curl http://34.171.63.140:8000/demo

# Test root
echo -e "\n3. Service Info:"
curl http://34.171.63.140:8000/

# Execute a task (needs API key - will fail but shows it's working)
echo -e "\n4. Try Execute (will need API key):"
curl -X POST http://34.171.63.140:8000/execute \
  -H "Content-Type: application/json" \
  -d '{"task": "Test from Cloud Shell", "context": {"user": "Chase"}}'

echo -e "\n✅ Orchestrator is LIVE and responding!"
