# Contributing to Agents GCP

Thank you for your interest in contributing to the Agents GCP project!

## Development Process

We use GitHub flow with the following branch strategy:

### Branch Structure
- `main` - Production-ready code
- `dev` - Development integration branch
- `feature/*` - Feature branches
- `bugfix/*` - Bug fix branches
- `hotfix/*` - Emergency production fixes

### Workflow

1. **Create a feature branch**
   ```bash
   git checkout dev
   git pull origin dev
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**
   - Write clean, documented code
   - Follow the style guide
   - Add tests for new functionality
   - Update documentation as needed

3. **Test your changes**
   ```bash
   make test
   make lint
   ```

4. **Commit your changes**
   ```bash
   git add .
   git commit -m "feat: add new feature"
   ```
   
   Follow conventional commits:
   - `feat:` New feature
   - `fix:` Bug fix
   - `docs:` Documentation changes
   - `test:` Test additions/changes
   - `refactor:` Code refactoring
   - `chore:` Maintenance tasks

5. **Push and create PR**
   ```bash
   git push origin feature/your-feature-name
   gh pr create --base dev
   ```

## Code Standards

### Python Style
- Follow PEP 8
- Use type hints
- Maximum line length: 100 characters
- Use Black for formatting
- Use Ruff for linting

### Documentation
- All functions must have docstrings
- Use Google-style docstrings
- Update README for user-facing changes
- Add inline comments for complex logic

### Testing
- Maintain >80% code coverage
- Write unit tests for all new functions
- Add integration tests for new features
- Include E2E tests for critical paths

## Pull Request Process

1. **PR Requirements**
   - All tests must pass
   - Code coverage must not decrease
   - No linting errors
   - Documentation updated
   - PR description explains changes

2. **Review Process**
   - At least one approval required
   - Address all review comments
   - Squash commits before merge

3. **Merge Strategy**
   - Feature → Dev: Squash and merge
   - Dev → Main: Create merge commit
   - Hotfix → Main: Create merge commit

## Security

- Never commit secrets or credentials
- Use environment variables for configuration
- Report security issues privately
- Follow OWASP guidelines

## Getting Help

- Check existing issues and PRs
- Read the documentation
- Ask questions in discussions
- Contact the maintainers

## License

By contributing, you agree that your contributions will be licensed under the project's proprietary license.